package controlador;

import dao.DetalleFacturaDao;
import modelo.DetalleFactura;

public class ControladorDetalleFactura {
    
    private DetalleFacturaDao detalleFacturaDao = new DetalleFacturaDao();
    
    public boolean registrarCabeceraFactura(DetalleFactura detalleFactura){
        
        return detalleFacturaDao.registrarDetalleFactura(detalleFactura);
    }
    
}
