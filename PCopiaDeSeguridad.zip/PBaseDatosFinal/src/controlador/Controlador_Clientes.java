/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import dao.PersonalDao;
import java.util.ArrayList;
import modelo.Persona;

/**
 *
 * @author Lenovo
 */
public class Controlador_Clientes 
{
    private PersonalDao perDao=new PersonalDao();
    
    public int registarCliente(Persona persona){
        return perDao.registrarPersona(persona);
    }
    public Persona buscarPersonal(String cedula){
        return perDao.buscarPersonal(cedula);
    }
    //Buscar todas las citas que tiene agendada el cliente
    public ArrayList<Persona> buscarListaPersonalr(String codigo){
        return perDao.buscarListaPersonal(codigo);
    }
    public boolean actualizarPersona(Persona persona){
        return perDao.actualizarPersona(persona);
    }
    public boolean eliminarPersona(String cedula){
        return perDao.eliminarPersona(cedula);
    }
    
}
