package controlador;

import dao.CabeceraFacturaDao;
import java.util.ArrayList;
import modelo.CabeceraFactura;

public class ControladorCabeceraFactura {
    
    private CabeceraFacturaDao cabeceraFacturaDao = new CabeceraFacturaDao();
    
    public boolean registrarCabeceraFactura(CabeceraFactura cabeceraFactura){
        
        return cabeceraFacturaDao.registrarCabeceraFactura(cabeceraFactura);
    }
    
    public int numeroFactura(){
        return cabeceraFacturaDao.numeroFactura();
    }
    
    public ArrayList<CabeceraFactura> listarCabecerasFacturas(){
        return cabeceraFacturaDao.listarCabecerasFacturas();
    }
    public boolean anularFactura(int codigo,String estado){
        return cabeceraFacturaDao.anularFactura(codigo, estado);
    }
}
