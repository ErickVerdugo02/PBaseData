package controlador;

import dao.ServicioDao;
import modelo.Servicio;

public class ControladorServicio {
    
    private ServicioDao servicioDao = new ServicioDao();
    
    public boolean registarServicio(Servicio servicio){
        return servicioDao.registrarServicio(servicio);
    }
    
    public Servicio buscarServicio(String nombre){
        
        return servicioDao.buscarServicio(nombre);
    }
       
    public boolean actualizarServicio(Servicio servicio){
        return servicioDao.actualizarServicio(servicio);
    }
    
    public boolean eliminarServicio(int codigo){
        return servicioDao.eliminarServicio(codigo);
    }
}
