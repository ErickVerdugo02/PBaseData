/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import dao.TipoMascotaDao;
import java.util.ArrayList;
import modelo.MascotaTipo;

/**
 *
 * @author Lenovo
 */
public class ControladorTipoMascota 
{
    private TipoMascotaDao mascotaDao=new TipoMascotaDao();
    
    public MascotaTipo buscarTipoMascota(String codigo){
        return mascotaDao.buscarTipoMascota(codigo);
    }
    public ArrayList<MascotaTipo> buscarListaTipoMascota(){
        return mascotaDao.buscarListaTipoMascota();
    }
    public int registrarTipoMascota(MascotaTipo mt){
        return mascotaDao.registrarTipoMascota(mt);
    }
    public boolean eliminarTipoMascota(String nombre){
        return mascotaDao.eliminarTipoMascota(nombre);
    }
    
}
