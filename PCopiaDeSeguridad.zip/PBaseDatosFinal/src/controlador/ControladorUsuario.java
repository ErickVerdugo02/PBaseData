package controlador;

import modelo.Usuario;
import dao.UsuarioDao;


public class ControladorUsuario 
{
    private Usuario usuario;
    private UsuarioDao usuDao = new UsuarioDao();
    
    public boolean registrarUsuario(Usuario usuario){
        return usuDao.registroUsuario(usuario);
    }
        
    public void setUsuarioDao(UsuarioDao usuDao){
        this.usuDao=usuDao;
    }
    
    public String ingresoUsuario(String usuario,String contrasenia)
    {
        return usuDao.validarUsuario(usuario, contrasenia);
    }
    
    public String[] buscarUsuario(String cedula){
        return usuDao.buscarUsuario(cedula);
    }
    
    public boolean activarUsuario(int codigo){
        return usuDao.activarUsuario(codigo);
    }
    
    public boolean desactivarUsuario(int codigo){
        return usuDao.desactivarUsuario(codigo);
    }
    
    public Usuario obtenerUsuario(String nombre){
        return usuDao.obtenerUsuario(nombre);
    }
        
}
