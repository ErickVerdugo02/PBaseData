package controlador;

import dao.PersonalDao;
import java.util.ArrayList;
import modelo.Persona;


public class ControladorPersonal 
{
    private PersonalDao perDao=new PersonalDao();
    
    public void setPersonalDao(PersonalDao perDao){
        this.perDao=perDao;
    }
    
    public Persona buscarPersonal(String cedula)
    {
        return perDao.buscarPersonal(cedula);
    }
    
    public Persona buscarPersonalCod(String codigo)
    {
        return perDao.buscarPersonalCod(codigo);
    }
    
    public Persona buscarPersonalNom(String nombre){
        return perDao.buscarPersonalNom(nombre);
    }
    
    public Persona buscarPersona2(String codigo)
    {
        return perDao.buscarPersona2(codigo);
    }
        
}
