/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import dao.CitaDao;
import java.sql.Timestamp;
import java.util.ArrayList;
import modelo.Cita;

/**
 *
 * @author Lenovo
 */
public class ControladorCita 
{
    private CitaDao citaDao=new CitaDao();
    //Buscar la cita con el codigo
    public Cita buscarCita(String codigo){
        return citaDao.buscarCita(codigo);
    }
    //Buscar todas las citas que tiene agendada el cliente
    public ArrayList<Cita> buscarCitaPer(String codigo){
        return citaDao.buscarCitaPer(codigo);
    }
    //Registrar la cita
    public int registrarCita(Cita cita)
    {
        return citaDao.registrarCita(cita);
    }
    //Reagendar la cita
    public boolean reagendarCita(Timestamp fecha,int codigo){
        return citaDao.reagendarCita(fecha, codigo);
    }
    //Cancelar la cita
    public boolean cancelarCita(String estado,int codigo){
        return citaDao.cancelarCita(estado, codigo);
    }
    public ArrayList<Cita> listarCitas(){
        return citaDao.listarCitas();
    }
}
