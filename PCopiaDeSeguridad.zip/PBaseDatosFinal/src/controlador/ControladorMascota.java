/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import dao.MascotaDao;
import java.util.ArrayList;
import modelo.Mascota;

/**
 *
 * @author Lenovo
 */
public class ControladorMascota
{
    private MascotaDao masDao=new MascotaDao();
    public ArrayList<Mascota> buscarMascotaPer(String codigo)
    {
        return masDao.buscarMascotaPer(codigo);
    }
    public ArrayList<Mascota> buscarMascotaNom(String nombre)
    {
        return masDao.buscarMascotaNom(nombre);
    }
    public ArrayList<Mascota> buscarListaMascota()
    {
        return masDao.buscarListaMascota();
    }
    public Mascota buscarMascotaCod(String codigo)
    {
        return masDao.buscarMascotaCod(codigo);
    }
    public int registrarMascota(String nombre,int perCod,int masTipo)
    {
        return masDao.registrarMascota(nombre, perCod, masTipo);
    }
    public boolean eliminarMascota(String nombre){
        return masDao.eliminarMascota(nombre);
    }
    public boolean actualizarMascota(Mascota mascota){
        return masDao.actualizarMascota(mascota);
    }
    
}
