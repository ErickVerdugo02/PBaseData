package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import modelo.*;

public class DetalleFacturaDao {
    Conexion conexion=new Conexion();
    String SQLr="";
    ResultSet listado;
    
    public boolean registrarDetalleFactura(DetalleFactura detalleFactura) {
        boolean llave=false;
        try {
            
            SQLr = "INSERT INTO vte_detalles_facturas VALUES (seq_det_codigo.nextval, ?, ?, ?, ?, ?, ?, ?)";
            Connection con = conexion.conectar();
            PreparedStatement sentencia = con.prepareStatement(SQLr);
            
            sentencia.setInt(1, detalleFactura.getCantidad());
            sentencia.setDouble(2, detalleFactura.getPrecio());
            sentencia.setDouble(3, detalleFactura.getSubtotalDetalle());
            sentencia.setDouble(4, detalleFactura.getIvaDetalle());
            sentencia.setDouble(5, detalleFactura.getTotalDetalle());
            sentencia.setInt(6, detalleFactura.getCodigoFacura());
            sentencia.setInt(7, detalleFactura.getServicioCodigo());
            
            int filasAfectadas = sentencia.executeUpdate();

            if (filasAfectadas > 0) {
                System.out.println("Factura generada exitosamente");
            } else {
                System.out.println("No se pudo generar la factura");
            }
            
            llave=true;
            sentencia.close();
            con.close();
        } catch (SQLException ex) {
            System.out.println(ex);
        }
        return llave;
    }
        
}
