package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import modelo.*;

public class ServicioDao {
    Conexion conexion=new Conexion();
    String SQLr="";
    ResultSet listado;
    Servicio servicio;
    
    public boolean registrarServicio(Servicio servicio) {
        boolean llave=false;
        try {
            
            SQLr = "INSERT INTO vte_servicios VALUES (seq_ser_codigo.NEXTVAL, ?, ?, ?)";
            Connection con = conexion.conectar();
            PreparedStatement sentencia = con.prepareStatement(SQLr);
            sentencia.setString(1, servicio.getNombre());
            sentencia.setDouble(2, servicio.getPrecio());
            sentencia.setInt(3, Integer.parseInt(String.valueOf(servicio.getIva())));
            
            int filasAfectadas = sentencia.executeUpdate();

            if (filasAfectadas > 0) {
                System.out.println("Se guardó correctamente el servicio");
            } else {
                System.out.println("No se pudo guardar el servicio.");
            }
            llave=true;
            sentencia.close();
            con.close();
        } catch (SQLException ex) {
            System.out.println(ex);
        }
        return llave;
    }
    
    public Servicio buscarServicio(String nombre) {


        try {
            SQLr = "SELECT * FROM vte_servicios where ser_nombre=?";
            Connection con = conexion.conectar();
            PreparedStatement sentencia = con.prepareStatement(SQLr);
            sentencia.setString(1, nombre);
            listado = sentencia.executeQuery();
            
            if (listado.next()) {
                // Mientras haya registros en el ResultSet, iteramos y accedemos a los valores de las columnas
                int codigo = listado.getInt("ser_codigo");
                String nombre2 = listado.getString("ser_nombre");
                double precio = listado.getDouble("ser_precio");
                int iva = listado.getInt("ser_iva");
                
                servicio = new Servicio(codigo, nombre2, precio, String.valueOf(iva).charAt(0), 'a');
            } else {
                System.out.println("No se encontraron resultados.");
            }

        } catch (SQLException ex) {
            System.out.println(ex);
        }
        return servicio;
    }
    
    public boolean actualizarServicio(Servicio servicio){
        boolean llave = false;
        try {
            SQLr = "UPDATE vte_servicios SET ser_nombre=?, ser_precio=?, ser_iva=? WHERE ser_codigo=?";
            Connection con = conexion.conectar();
            PreparedStatement sentencia = con.prepareStatement(SQLr);
            sentencia.setString(1, servicio.getNombre());
            sentencia.setDouble(2, servicio.getPrecio());
            sentencia.setInt(3, Integer.parseInt(String.valueOf(servicio.getIva()))); 
            sentencia.setInt(4, servicio.getCodigo());
            
            int res = sentencia.executeUpdate(); 
            
            if (res > 0) {
                llave = true;
                return llave;
            }
            
        } catch (SQLException ex) {
            System.out.println(ex);
        }
        
        return llave;
    }
    
    public boolean eliminarServicio(int codigo){
        boolean llave = false;
        try {
            SQLr = "DELETE vte_servicios WHERE ser_codigo=?";
            Connection con = conexion.conectar();
            PreparedStatement sentencia = con.prepareStatement(SQLr);
            sentencia.setInt(1, codigo);
            int res = sentencia.executeUpdate();
            
            if (res > 0) {
                llave = true;
                return llave;
            }
            
        } catch (SQLException ex) {
            System.out.println(ex);
        }
        
        return llave;
    }
        
}
