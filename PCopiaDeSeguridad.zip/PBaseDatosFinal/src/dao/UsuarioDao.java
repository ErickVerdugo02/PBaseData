package dao;


import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import modelo.Usuario;

public class UsuarioDao 
{
    Conexion conexion=new Conexion();
    String SQLr="";
    ResultSet listado;
    Usuario usuario = null;
    
    public ResultSet buscarUsuarios(String usuario, String contrasenia) {


        try {
            SQLr = "SELECT * FROM vte_usuarios where usu_usuario=? and usu_clave=?";
            Connection con = conexion.conectar();
            PreparedStatement sentencia = con.prepareStatement(SQLr);
            sentencia.setString(1, usuario);
            sentencia.setString(2, contrasenia);
            listado = sentencia.executeQuery();
            return listado;

        } catch (SQLException ex) {
            System.out.println(ex);
        }
        return null;
    }
    
    public String validarUsuario(String usuario, String contrasenia)
    {
        String permiso="";
        boolean existeUsuario = false;
        listado = buscarUsuarios(usuario, contrasenia);
        try {
            //Recorre bucle y en el caso de que si exista el usuario el estado pasa a verdadero
            while (listado.next()) {
                existeUsuario = true;
            }
            if (existeUsuario == true) {
                listado = buscarUsuarios(usuario, contrasenia);
                if (listado.next()) {
                // Aquí puedes obtener el valor de la columna por su nombre o su índice (empezando desde 1)
                    permiso = listado.getString(4);
                } else {
                    System.out.println("No se encontraron resultados.");
                }
                listado.close();
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex);
        }
        return permiso;
    }
    
    public boolean registroUsuario(Usuario usuario){
        boolean llave = false;
        try {
            SQLr = "INSERT INTO vte_usuarios VALUES (seq_usu_codigo.NEXTVAL, ?, ?, ?, ?)";
            Connection con = conexion.conectar();
            PreparedStatement sentencia = con.prepareStatement(SQLr);
            sentencia.setString(1, usuario.getUsername());
            sentencia.setString(2, usuario.getContrasenia());
            sentencia.setString(3, String.valueOf(usuario.getPermiso())); 
            sentencia.setInt(4, usuario.getCodigo_per());
            int filasAfectadas = sentencia.executeUpdate();
            
            if (filasAfectadas > 0) {
                System.out.println("Se guardó correctamente la cita");
                llave = true;
                sentencia.close();
                con.close();
            
            } else {
                System.out.println("No se pudo guardar la cita");
                llave = false;
                sentencia.close();
                con.close();
            }
                        
        } catch (SQLException ex) {
            System.out.println(ex);
        }
        
        return llave;
    }
    
    
    public String[] buscarUsuario(String cedula){
        String datosUsuario[] = new String[5];  
        
        try {
            SQLr = "SELECT * FROM vte_personas where per_cedula=?";
            Connection con = conexion.conectar();
            PreparedStatement sentencia = con.prepareStatement(SQLr);
            sentencia.setString(1, cedula);
            listado = sentencia.executeQuery();
            
            if (listado.next()) {
                int codigo = listado.getInt("per_codigo");
                String nombres = listado.getString("per_nombre");
                nombres = nombres + " " + listado.getString("per_apellido"); 
                
                //1102284143
                usuario = this.buscarUsuarioCodigo(codigo);
                
                datosUsuario[0] = String.valueOf(usuario.getCodigo());
                datosUsuario[1] = usuario.getUsername();
                datosUsuario[2] = usuario.getContrasenia();
                datosUsuario[3] = String.valueOf(usuario.getPermiso());
                datosUsuario[4] =  nombres;
            }
            
        } catch (SQLException ex) {
            System.out.println(ex);
        }
        
        return datosUsuario;
    }
    
    public Usuario buscarUsuarioCodigo(int codigo){
        try {
            SQLr = "SELECT * FROM vte_usuarios where vte_personas_per_codigo=?";
            Connection con = conexion.conectar();
            PreparedStatement sentencia = con.prepareStatement(SQLr);
            sentencia.setInt(1, codigo);
            listado = sentencia.executeQuery();
            
            if (listado.next()) {
                int codigo2 = listado.getInt("usu_codigo");
                String username = listado.getString("usu_usuario");
                String password = listado.getString("usu_clave");
                String perimiso = listado.getString("usu_permiso");
                int codigoPer = listado.getInt("vte_personas_per_codigo");
                
                usuario = new Usuario(codigo2, codigoPer, username, password, perimiso.charAt(0), '-'); 
            }
        } catch (SQLException ex) {
            System.out.println(ex);
        }
                
        return usuario;
    }
    
    public boolean activarUsuario(int codigo){
        boolean llave = false;
        try {
            SQLr = "UPDATE vte_usuarios SET usu_permiso=? WHERE usu_codigo=?";
            Connection con = conexion.conectar();
            PreparedStatement sentencia = con.prepareStatement(SQLr);
            sentencia.setString(1, "A");
            sentencia.setInt(2, codigo);
            int res = sentencia.executeUpdate();
            
            if (res > 0) {
                llave = true;
                return llave;
            }
            
        } catch (SQLException ex) {
            System.out.println(ex);
        }
        
        return llave;
    }
    
    public boolean desactivarUsuario(int codigo){
        boolean llave = false;
        try {
            SQLr = "UPDATE vte_usuarios SET usu_permiso=? WHERE usu_codigo=?";
            Connection con = conexion.conectar();
            PreparedStatement sentencia = con.prepareStatement(SQLr);
            sentencia.setString(1, "G");
            sentencia.setInt(2, codigo);
            int res = sentencia.executeUpdate();
            
            if (res > 0) {
                llave = true;
                return llave;
            }
            
        } catch (SQLException ex) {
            System.out.println(ex);
        }
        
        return llave;
    }
    
    public Usuario obtenerUsuario(String nombre){
        try {
            SQLr = "SELECT * FROM vte_usuarios where usu_usuario=?";
            Connection con = conexion.conectar();
            PreparedStatement sentencia = con.prepareStatement(SQLr);
            sentencia.setString(1, nombre);
            listado = sentencia.executeQuery();
            
            if (listado.next()) {
                int codigo2 = listado.getInt("usu_codigo");
                String username = listado.getString("usu_usuario");
                String password = listado.getString("usu_clave");
                String perimiso = listado.getString("usu_permiso");
                int codigoPer = listado.getInt("vte_personas_per_codigo");
                
                usuario = new Usuario(codigo2, codigoPer, username, password, perimiso.charAt(0), '-'); 
            }
        } catch (SQLException ex) {
            System.out.println(ex);
        }
                
        return usuario;
    }
        
}
