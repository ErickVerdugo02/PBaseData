package dao;

import java.security.Timestamp;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import modelo.*;

public class CabeceraFacturaDao {
    Conexion conexion=new Conexion();
    String SQLr="";
    ResultSet listado;
    CabeceraFactura cabeceraFactura;
    
    public boolean registrarCabeceraFactura(CabeceraFactura cabeceraFactura) {
        boolean llave=false;
        try {
            
            SQLr = "INSERT INTO vte_cabeceras_facturas VALUES (seq_fac_codigo.nextval, ?, ?, ?, ?, ?, ?, ?)";
            Connection con = conexion.conectar();
            PreparedStatement sentencia = con.prepareStatement(SQLr);
            
            sentencia.setTimestamp(1, cabeceraFactura.getFecha());
            sentencia.setDouble(2, cabeceraFactura.getSubtotal());
            sentencia.setDouble(3, cabeceraFactura.getTotal_iva());
            sentencia.setDouble(4, cabeceraFactura.getTotal());
            sentencia.setDouble(5, cabeceraFactura.getCodigo_usuario());
            sentencia.setDouble(6, cabeceraFactura.getCodigo_per());
            sentencia.setString(7, cabeceraFactura.getEstado());
            
            int filasAfectadas = sentencia.executeUpdate();

            if (filasAfectadas > 0) {
                System.out.println("Factura generada exitosamente");
            } else {
                System.out.println("No se pudo generar la factura");
            }
            
            llave=true;
            sentencia.close();
            con.close();
        } catch (SQLException ex) {
            System.out.println(ex);
        }
        return llave;
    }
        
    public int numeroFactura() {
        int numeroFactura=-1;
        
        try {
            SQLr = "SELECT MAX(fac_codigo) AS max_value FROM vte_cabeceras_facturas";
            Connection con = conexion.conectar();
            PreparedStatement sentencia = con.prepareStatement(SQLr);
            listado = sentencia.executeQuery();
            
            if (listado.next()) {
                // Mientras haya registros en el ResultSet, iteramos y accedemos a los valores de las columnas
                numeroFactura = listado.getInt("max_value");
                
            } else {
                System.out.println("No se encontraron resultados.");
            }

        } catch (SQLException ex) {
            System.out.println(ex);
        }
        
        return numeroFactura;
    }
    
    public ArrayList<CabeceraFactura> listarCabecerasFacturas() {
        
        ArrayList<CabeceraFactura> listaCabeceras = new ArrayList<>();
        String SQLl = "SELECT * FROM vte_cabeceras_facturas ORDER BY 1";

        try {
            Connection con = conexion.conectar();
            PreparedStatement sentencia = con.prepareStatement(SQLl);
            ResultSet resultado = sentencia.executeQuery();

            while (resultado.next()) {
                CabeceraFactura cabecera = new CabeceraFactura();
                cabecera.setCodigo(resultado.getInt(1));
                cabecera.setFecha(resultado.getTimestamp(2));
                cabecera.setSubtotal(resultado.getDouble(3));
                cabecera.setTotal_iva(resultado.getDouble(4));
                cabecera.setTotal(resultado.getDouble(5));
                cabecera.setCodigo_usuario(resultado.getInt(6));
                cabecera.setCodigo_per(resultado.getInt(7));
                cabecera.setEstado(resultado.getString(8));
                System.out.println("CABECERA: "+cabecera);
                listaCabeceras.add(cabecera);
            }

            resultado.close();
            sentencia.close();
            con.close();

        } catch (SQLException ex) {
            System.out.println(ex);
        }

        return listaCabeceras;
    }

    public boolean anularFactura(int codigo,String estado){
        boolean llave=false;
        try {
            
            SQLr = "UPDATE vte_cabeceras_facturas SET fac_estado = ? WHERE fac_codigo = ?";
            Connection con = conexion.conectar();
            PreparedStatement sentencia = con.prepareStatement(SQLr);
            sentencia.setString(1, estado);
            sentencia.setInt(2, codigo);
            
            int filasAfectadas = sentencia.executeUpdate();

            if (filasAfectadas > 0) {
                System.out.println("Se actualizo correctamente la cabecera factura");
            } else {
                System.out.println("No se actualizo correctamente la cabecera factura.");
            }
            llave=true;
            sentencia.close();
            con.close();
        } catch (SQLException ex) {
            System.out.println(ex);
        }
        return llave;
    }
}
