package dao;


import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import modelo.Persona;



public class PersonalDao {

    Conexion conexion = new Conexion();
    String SQLr = "";
    ResultSet listado;
    Persona p = null;
    ArrayList<Persona> personas = new ArrayList<Persona>();
    public Persona buscarPersonalCod(String codigo) {

        try {
            SQLr = "SELECT * FROM vte_personas where per_codigo=?";
            Connection con = conexion.conectar();
            PreparedStatement sentencia = con.prepareStatement(SQLr);
            sentencia.setString(1, codigo);
            listado = sentencia.executeQuery();

            if (listado.next()) {
                // Mientras haya registros en el ResultSet, iteramos y accedemos a los valores de las columnas
                String codigo2 = listado.getString("per_codigo");
                String cedula = listado.getString("per_cedula");
                String nombre = listado.getString("per_nombre");
                String apellido = listado.getString("per_apellido");
                String direccion = listado.getString("per_direccion");
                String telefono = listado.getString("per_telefono");
                String correo = listado.getString("per_correo");
                String tipo = listado.getString("per_tipo");
                String estado = listado.getString("per_estado");

                p = new Persona(Integer.parseInt(codigo2), cedula, nombre,
                        apellido, direccion, telefono, correo, tipo.charAt(0), estado.charAt(0));
                
                return p;

            } else {
                System.out.println("No se encontraron resultados.");
            }

        } catch (SQLException ex) {
            System.out.println(ex);
        }
        return p;
    }
    
    public Persona buscarPersonal(String cedula) {

        try {
            SQLr = "SELECT * FROM vte_personas where per_cedula=?";
            Connection con = conexion.conectar();
            PreparedStatement sentencia = con.prepareStatement(SQLr);
            sentencia.setString(1, cedula);
            listado = sentencia.executeQuery();

            if (listado.next()) {
                // Mientras haya registros en el ResultSet, iteramos y accedemos a los valores de las columnas
                String codigo = listado.getString("per_codigo");
                String cedula2 = listado.getString("per_cedula");
                String nombre = listado.getString("per_nombre");
                String apellido = listado.getString("per_apellido");
                String direccion = listado.getString("per_direccion");
                String telefono = listado.getString("per_telefono");
                String correo = listado.getString("per_correo");
                String tipo = listado.getString("per_tipo");
                String estado = listado.getString("per_estado");

                p = new Persona(Integer.parseInt(codigo), cedula2, nombre,
                        apellido, direccion, telefono, correo, tipo.charAt(0), estado.charAt(0));
                
                return p;

            } else {
                System.out.println("No se encontraron resultados.");
            }

        } catch (SQLException ex) {
            System.out.println(ex);
        }
        return p;
    }

    public Persona buscarPersonalNom(String nombre) {
        try {
            SQLr = "SELECT * FROM vte_personas where per_nombre=?";
            Connection con = conexion.conectar();
            PreparedStatement sentencia = con.prepareStatement(SQLr);
            sentencia.setString(1, nombre);
            listado = sentencia.executeQuery();

            if (listado.next()) {
                // Mientras haya registros en el ResultSet, iteramos y accedemos a los valores de las columnas
                String codigo = listado.getString("per_codigo");
                String cedula = listado.getString("per_cedula");
                String nombre2 = listado.getString("per_nombre");
                String apellido = listado.getString("per_apellido");
                String direccion = listado.getString("per_direccion");
                String telefono = listado.getString("per_telefono");
                String correo = listado.getString("per_correo");
                String tipo = listado.getString("per_tipo");
                String estado = listado.getString("per_estado");

                p = new Persona(Integer.parseInt(codigo), cedula, nombre2,
                        apellido, direccion, telefono, correo, tipo.charAt(0), estado.charAt(0));
                return p;

            } else {
                System.out.println("No se encontraron resultados.");
            }

        } catch (SQLException ex) {
            System.out.println(ex);
        }
        return p;
    }

    public ArrayList<Persona> buscarListaPersonal(String cedula) {
        try {

            SQLr = "SELECT * FROM vte_personas where per_cedula=?";
            Connection con = conexion.conectar();
            PreparedStatement sentencia = con.prepareStatement(SQLr);
            sentencia.setString(1, cedula);
            listado = sentencia.executeQuery();
            while (listado.next()) {
                // Mientras haya registros en el ResultSet, iteramos y accedemos a los valores de las columnas
                String codigo = listado.getString("per_codigo");
                String cedula2 = listado.getString("per_cedula");
                String nombres = listado.getString("per_nombre");
                String apellidos = listado.getString("per_apellido");
                String direccion = listado.getString("per_direccion");
                String telefono = listado.getString("vte_telefono");
                String correo = listado.getString("vte_correo");
                String tipo = listado.getString("vte_tipo");
                String estado = listado.getString("vte_estado");

                p = new Persona(Integer.parseInt(codigo), cedula2, nombres, apellidos,
                        direccion, telefono, correo, tipo.charAt(0), estado.charAt(0));
                personas.add(p);
            }
        } catch (SQLException ex) {
            System.out.println(ex);
        }
        return personas;
    }
    
    public int registrarPersona(Persona persona) {
        int codigoAsignado = -1;//Codigo de la cita agendada
        try {
            System.out.println("Esta es la: " + persona);
            System.out.println("PERSONA: " + persona.getTelefono());
            SQLr = "INSERT INTO vte_personas VALUES (seq_per_codigo.nextval, ?, ?, ?, ?, ?, ?, ?, ?)";
            Connection con = conexion.conectar();
            PreparedStatement sentencia = con.prepareStatement(SQLr);
            sentencia.setString(1, persona.getCedula());
            sentencia.setString(2, persona.getNombres());
            sentencia.setString(3, persona.getApellidos());
            sentencia.setString(4, persona.getDireccion());
            sentencia.setString(5, persona.getTelefono());
            sentencia.setString(6, persona.getCorreo());
            sentencia.setString(7, String.valueOf(persona.getTipo()));
            sentencia.setString(8, String.valueOf(persona.getEstado()));

            int filasAfectadas = sentencia.executeUpdate();

            if (filasAfectadas > 0) {
                System.out.println("Se guardó correctamente la persona");

                // Consulta para obtener el código asignado por la secuencia
                String sqlObtenerCodigo = "SELECT seq_per_codigo.CURRVAL FROM DUAL";
                PreparedStatement sentenciaCodigo = con.prepareStatement(sqlObtenerCodigo);
                ResultSet resultado = sentenciaCodigo.executeQuery();

                if (resultado.next()) {
                    codigoAsignado = resultado.getInt(1);
                    System.out.println("Código asignado: " + codigoAsignado);
                }

                sentenciaCodigo.close();
            } else {
                System.out.println("No se pudo guardar la persona");
            }
            sentencia.close();
            con.close();
        } catch (SQLException ex) {
            System.out.println(ex);
        }
        System.out.println("Codigo 1: " + codigoAsignado);
        return codigoAsignado;
    }

    public boolean actualizarPersona(Persona persona) {
        boolean llave = false;
        try {
            SQLr = "UPDATE vte_personas SET per_nombre=?, per_apellido=?, per_direccion=?, per_telefono=?, per_correo=?, per_tipo=?, per_estado=? WHERE per_cedula=?";
            Connection con = conexion.conectar();
            PreparedStatement sentencia = con.prepareStatement(SQLr);

            sentencia.setString(1, persona.getNombres());
            sentencia.setString(2, persona.getApellidos());
            sentencia.setString(3, persona.getDireccion());
            sentencia.setString(4, persona.getTelefono());
            sentencia.setString(5, persona.getCorreo());
            sentencia.setString(6, String.valueOf(persona.getTipo()));
            sentencia.setString(7, String.valueOf(persona.getEstado()));
            sentencia.setString(8, persona.getCedula());

            int filasAfectadas = sentencia.executeUpdate();

            if (filasAfectadas > 0) {
                System.out.println("Se actualizó correctamente la persona");
            } else {
                System.out.println("No se pudo actualizar la persona");
            }
            sentencia.close();
            con.close();
            llave = true;
        } catch (SQLException ex) {
            System.out.println(ex);
        }
        return llave;
    }

    public boolean eliminarPersona(String cedula) {
        boolean llave = false;
        System.out.println("Cedula12: "+cedula);
        try {
            String SQLr = "DELETE  FROM vte_personas WHERE per_cedula= ? ";
            Connection con = conexion.conectar();
            PreparedStatement sentencia = con.prepareStatement(SQLr);
            sentencia.setString(1, cedula);
            int filasAfectadas = sentencia.executeUpdate();
            if (filasAfectadas > 0) {
                System.out.println("Se eliminó correctamente la persona con cédula " + cedula);
                llave = true;
            } else {
                System.out.println("No se pudo eliminar la persona con cédula " + cedula + " (No existe en la base de datos)");
            }
            sentencia.close();
            con.close();
        } catch (SQLException ex) {
            System.out.println(ex);
        }
        return llave;
    }
    
    
    public Persona buscarPersona2(String codigo) {


        try {
            SQLr = "SELECT * FROM vte_personas where per_codigo=?";
            Connection con = conexion.conectar();
            PreparedStatement sentencia = con.prepareStatement(SQLr);
            sentencia.setInt(1, Integer.parseInt(codigo));
            listado = sentencia.executeQuery();
            
            if (listado.next()) {
                // Mientras haya registros en el ResultSet, iteramos y accedemos a los valores de las columnas
                String codigo2 = listado.getString("per_codigo");
                String cedula = listado.getString("per_cedula");
                String nombre = listado.getString("per_nombre");
                String apellido = listado.getString("per_apellido");
                String direccion = listado.getString("per_direccion");
                String telefono = listado.getString("per_telefono");
                String correo = listado.getString("per_correo");
                String tipo = listado.getString("per_tipo");
                String estado = listado.getString("per_estado");
                
                p=new Persona(Integer.parseInt(codigo),cedula,nombre,
                        apellido,direccion,telefono,correo,tipo.charAt(0),estado.charAt(0));
                return p;
                
            } else {
                System.out.println("No se encontraron resultados.");
            }

        } catch (SQLException ex) {
            System.out.println(ex);
        }
        return p;
    }

}
