/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import modelo.MascotaTipo;
import modelo.Persona;

/**
 *
 * @author Lenovo
 */
public class TipoMascotaDao {
    Conexion conexion = new Conexion();
    ArrayList<MascotaTipo> mascotas=new ArrayList<MascotaTipo>();
    String SQLr = "";
    ResultSet listado;
    MascotaTipo mt = null;
    public MascotaTipo buscarTipoMascota(String codigo){
        try {
            SQLr = "SELECT * FROM vte_mascotas_tipos where tipo_codigo=?";
            Connection con = conexion.conectar();
            PreparedStatement sentencia = con.prepareStatement(SQLr);
            sentencia.setString(1, codigo);
            listado = sentencia.executeQuery();

            if (listado.next()) {
                // Mientras haya registros en el ResultSet, iteramos y accedemos a los valores de las columnas
                String codigo2 = listado.getString("tipo_codigo");
                String nombre = listado.getString("tipo_nombre");

                mt = new MascotaTipo(Integer.parseInt(codigo2), nombre);
                return mt;
            } else {
                System.out.println("No se encontraton tipos mascotas");
            }

        } catch (SQLException ex) {
            System.out.println(ex);
        }
        return mt;
    }
    public ArrayList<MascotaTipo> buscarListaTipoMascota(){
        try {
            mascotas=new ArrayList<MascotaTipo>();
            SQLr = "SELECT * FROM vte_mascotas_tipos ORDER BY 1";
            Connection con = conexion.conectar();
            PreparedStatement sentencia = con.prepareStatement(SQLr);
            listado = sentencia.executeQuery();

            while(listado.next()) {
                // Mientras haya registros en el ResultSet, iteramos y accedemos a los valores de las columnas
                String codigo = listado.getString("tipo_codigo");
                String nombre2 = listado.getString("tipo_nombre");

                mt = new MascotaTipo(Integer.parseInt(codigo), nombre2);
                mascotas.add(mt);
            }
        } catch (SQLException ex) {
            System.out.println(ex);
        }
        return mascotas;
    }
    
    public int registrarTipoMascota(MascotaTipo mt){
        int codigoAsignado = -1;//Codigo de la cita agendada
        try {
            
            SQLr = "INSERT INTO vte_mascotas_tipos VALUES (seq_tipo_codigo.nextval,?)";
            Connection con = conexion.conectar();
            PreparedStatement sentencia = con.prepareStatement(SQLr);
            sentencia.setString(1, mt.getNombre());
            
            int filasAfectadas = sentencia.executeUpdate();

            if (filasAfectadas > 0) {
                System.out.println("Se guardó correctamente la cita");

                // Consulta para obtener el código asignado por la secuencia
                String sqlObtenerCodigo = "SELECT seq_tipo_codigo.CURRVAL FROM DUAL";
                PreparedStatement sentenciaCodigo = con.prepareStatement(sqlObtenerCodigo);
                ResultSet resultado = sentenciaCodigo.executeQuery();

                if (resultado.next()) {
                    codigoAsignado = resultado.getInt(1);
                    System.out.println("Código asignado: " + codigoAsignado);
                }

                sentenciaCodigo.close();
            } else {
                System.out.println("No se pudo guardar la cita.");
            }
            sentencia.close();
            con.close();
        } catch (SQLException ex) {
            System.out.println(ex);
        }
        return codigoAsignado;
    }
    public boolean eliminarTipoMascota(String nombre){
        boolean llave = false;
        try {
            String SQLr = "DELETE  FROM vte_mascotas_tipos WHERE tipo_nombre= ?";
            Connection con = conexion.conectar();
            PreparedStatement sentencia = con.prepareStatement(SQLr);
            sentencia.setString(1, nombre);
            int filasAfectadas = sentencia.executeUpdate();
            if (filasAfectadas > 0) {
                System.out.println("Se eliminó correctamente la mascota tipo con nombre: " + nombre);
                llave = true;
            } else {
                System.out.println("No se pudo eliminar la mascota con el nombre " + nombre + " (No existe en la base de datos)");
            }
            sentencia.close();
            con.close();
        } catch (SQLException ex) {
            System.out.println(ex);
        }
        return llave;
    }
    
}
