/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.sql.Timestamp;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import modelo.Cita;
import modelo.Mascota;
import modelo.Persona;

/**
 *
 * @author Lenovo
 */
public class CitaDao {
    Conexion conexion=new Conexion();
    String SQLr="";
    ResultSet listado;
    Cita cita;
    ArrayList<Cita> citas=new ArrayList<Cita>();;
    
    public Cita buscarCita(String codigo){
        try {
            SQLr = "SELECT * FROM vte_citas where cit_codigo=?";
            Connection con = conexion.conectar();
            PreparedStatement sentencia = con.prepareStatement(SQLr);
            sentencia.setString(1, codigo);
            listado = sentencia.executeQuery();
            if(listado.next()) {
                // Mientras haya registros en el ResultSet, iteramos y accedemos a los valores de las columnas
                String codigo2 = listado.getString("cit_codigo");
                Timestamp fecha = listado.getTimestamp("cit_fecha_hora");
                String estado = listado.getString("cit_estado");
                String codigoPer = listado.getString("vte_personas_per_codigo");
                String codigoMas = listado.getString("vte_mascotas_mas_codigo");

                cita=new Cita(Integer.parseInt(codigo2+""),Integer.parseInt(codigoMas+""),
                Integer.parseInt(codigoPer+""),fecha,estado);
            }

        } catch (SQLException ex) {
            System.out.println(ex);
        }
        return cita;
    }
    public ArrayList<Cita> buscarCitaPer(String codigo){
        try {
            
            SQLr = "SELECT * FROM vte_citas where vte_personas_per_codigo=?";
            Connection con = conexion.conectar();
            PreparedStatement sentencia = con.prepareStatement(SQLr);
            sentencia.setString(1, codigo);
            listado = sentencia.executeQuery();
            while(listado.next()) {
                // Mientras haya registros en el ResultSet, iteramos y accedemos a los valores de las columnas
                String codigo2 = listado.getString("cit_codigo");
                Timestamp fecha = listado.getTimestamp("cit_fecha_hora");
                String estado = listado.getString("cit_estado");
                String codigoPer = listado.getString("vte_personas_per_codigo");
                String codigoMas = listado.getString("vte_mascotas_mas_codigo");

                cita=new Cita(Integer.parseInt(codigo2+""),Integer.parseInt(codigoMas+""),
                Integer.parseInt(codigoPer+""),fecha,estado);
                citas.add(cita);
            }

        } catch (SQLException ex) {
            System.out.println(ex);
        }
        return citas;
    }
    public int registrarCita(Cita cita) {
        int codigoAsignado = -1;//Codigo de la cita agendada
        try {
            
            SQLr = "INSERT INTO vte_citas VALUES (seq_cit_codigo.NEXTVAL,?, ?, ?, ?)";
            Connection con = conexion.conectar();
            PreparedStatement sentencia = con.prepareStatement(SQLr);
            sentencia.setTimestamp(1, cita.getFecha());
            sentencia.setString(2, cita.getEstado());
            sentencia.setInt(3, cita.getCodigo_per());
            sentencia.setInt(4, cita.getCodigo_mas());
            
            int filasAfectadas = sentencia.executeUpdate();

            if (filasAfectadas > 0) {
                System.out.println("Se guardó correctamente la cita");

                // Consulta para obtener el código asignado por la secuencia
                String sqlObtenerCodigo = "SELECT seq_cit_codigo.CURRVAL FROM DUAL";
                PreparedStatement sentenciaCodigo = con.prepareStatement(sqlObtenerCodigo);
                ResultSet resultado = sentenciaCodigo.executeQuery();

                if (resultado.next()) {
                    codigoAsignado = resultado.getInt(1);
                    System.out.println("Código asignado: " + codigoAsignado);
                }

                sentenciaCodigo.close();
            } else {
                System.out.println("No se pudo guardar la cita.");
            }
            sentencia.close();
            con.close();
        } catch (SQLException ex) {
            System.out.println(ex);
        }
        return codigoAsignado;
    }
    
    public boolean reagendarCita(Timestamp fecha,int codigo){
        boolean llave=false;
        try {
            System.out.println("FECHA: "+fecha);
            System.out.println("CODIGO: "+codigo);
            SQLr = "UPDATE vte_citas SET cit_fecha_hora = ? WHERE cit_codigo = ?";
            Connection con = conexion.conectar();
            PreparedStatement sentencia = con.prepareStatement(SQLr);
            sentencia.setTimestamp(1, fecha);
            sentencia.setInt(2, codigo);
            
            int filasAfectadas = sentencia.executeUpdate();

            if (filasAfectadas > 0) {
                System.out.println("Se guardó correctamente la cita");
            } else {
                System.out.println("No se pudo guardar la cita.");
            }
            llave=true;
            sentencia.close();
            con.close();
        } catch (SQLException ex) {
            System.out.println(ex);
        }
        return llave;
    }
    public boolean cancelarCita(String estado,int codigo){
        boolean llave=false;
        try {
            System.out.println("ESTADO: "+estado);
            System.out.println("CODIGO: "+codigo);
            SQLr = "UPDATE vte_citas SET cit_estado = ? WHERE cit_codigo = ?";
            Connection con = conexion.conectar();
            PreparedStatement sentencia = con.prepareStatement(SQLr);
            sentencia.setString(1, estado);
            sentencia.setInt(2, codigo);
            
            int filasAfectadas = sentencia.executeUpdate();

            if (filasAfectadas > 0) {
                System.out.println("Se cancelo correctamente la cita");
            } else {
                System.out.println("No se pudo cancelar la cita.");
            }
            llave=true;
            sentencia.close();
            con.close();
        } catch (SQLException ex) {
            System.out.println(ex);
        }
        return llave;
    }
    public ArrayList<Cita> listarCitas(){
        ArrayList<Cita> lista=new ArrayList<Cita>();
        //lista.clear();
        try {
            
            SQLr = "SELECT * FROM vte_citas";
            Connection con = conexion.conectar();
            PreparedStatement sentencia = con.prepareStatement(SQLr);
            listado = sentencia.executeQuery();
            while(listado.next()) {
                // Mientras haya registros en el ResultSet, iteramos y accedemos a los valores de las columnas
                String codigo2 = listado.getString("cit_codigo");
                Timestamp fecha = listado.getTimestamp("cit_fecha_hora");
                String estado = listado.getString("cit_estado");
                String codigoPer = listado.getString("vte_personas_per_codigo");
                String codigoMas = listado.getString("vte_mascotas_mas_codigo");

                cita=new Cita(Integer.parseInt(codigo2+""),Integer.parseInt(codigoMas+""),
                Integer.parseInt(codigoPer+""),fecha,estado);
                lista.add(cita);
            }

        } catch (SQLException ex) {
            System.out.println(ex);
        }
        return lista;
    }
}
