/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author Usuario
 */
public class Conexion {
    private static String user = "centroVeterinaria";
    private static String password = "veter";
    private static String url = "jdbc:oracle:thin:@localhost:1521:xe";
    private static String driver = "oracle.jdbc.driver.OracleDriver";
    
    private Connection conn;
    
    public Conexion (){
        this.conn = null;
    }
    
    public Connection conectar() {
        try {
            Class.forName(driver);
            System.out.println("756");
            this.conn = DriverManager.getConnection(url, user, password);
            System.out.println("Conectado");

        } catch (ClassNotFoundException | SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
           //System.out.println("No Conectado");
            System.exit(0);
        }
        return this.conn;

    }

    public void desconectar() {
        try {
            this.conn.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
}
