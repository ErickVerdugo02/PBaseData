/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

/**
 *
 * @author Lenovo
 */
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import modelo.Mascota;
import modelo.Persona;
public class MascotaDao 
{
    ArrayList<Mascota> mascotas=new ArrayList<Mascota>();
    Conexion conexion=new Conexion();
    String SQLr="";
    ResultSet listado;
    Mascota m=null;
    
    public Mascota buscarMascotaCod(String codigo) {
        
        try {
            SQLr = "SELECT * FROM vte_mascotas where mas_codigo=?";
            Connection con = conexion.conectar();
            PreparedStatement sentencia = con.prepareStatement(SQLr);
            sentencia.setString(1, codigo);
            listado = sentencia.executeQuery();
            if(listado.next()) {
                // Mientras haya registros en el ResultSet, iteramos y accedemos a los valores de las columnas
                String codigo2 = listado.getString("mas_codigo");
                String nombre = listado.getString("mas_nombre");
                String codigoPer = listado.getString("vte_personas_per_codigo");
                String codigoTipo = listado.getString("vte_mascotas_tipos_tipo_codigo");

                m = new Mascota(Integer.parseInt(codigo2), Integer.parseInt(codigoPer), Integer.parseInt(codigoTipo), nombre);
            }

        } catch (SQLException ex) {
            System.out.println(ex);
        }
        return m;
    }
    
    public ArrayList<Mascota> buscarMascotaPer(String codigo) {
        
        try {
            SQLr = "SELECT * FROM vte_mascotas where vte_personas_per_codigo=?";
            Connection con = conexion.conectar();
            PreparedStatement sentencia = con.prepareStatement(SQLr);
            sentencia.setString(1, codigo);
            listado = sentencia.executeQuery();
            while (listado.next()) {
                // Mientras haya registros en el ResultSet, iteramos y accedemos a los valores de las columnas
                String codigo2 = listado.getString("mas_codigo");
                String nombre = listado.getString("mas_nombre");
                String codigoPer = listado.getString("vte_personas_per_codigo");
                String codigoTipo = listado.getString("vte_mascotas_tipos_tipo_codigo");

                m = new Mascota(Integer.parseInt(codigo2), Integer.parseInt(codigoPer), Integer.parseInt(codigoTipo), nombre);
                mascotas.add(m);
            }

        } catch (SQLException ex) {
            System.out.println(ex);
        }
        return mascotas;
    }
    
    public ArrayList<Mascota> buscarMascotaNom(String nombre) {
        
        try {
            SQLr = "SELECT * FROM vte_mascotas where mas_nombre=?";
            Connection con = conexion.conectar();
            PreparedStatement sentencia = con.prepareStatement(SQLr);
            sentencia.setString(1, nombre);
            listado = sentencia.executeQuery();
            while (listado.next()) {
                // Mientras haya registros en el ResultSet, iteramos y accedemos a los valores de las columnas
                String codigo = listado.getString("mas_codigo");
                String nombre2 = listado.getString("mas_nombre");
                String codigoPer = listado.getString("vte_personas_per_codigo");
                String codigoTipo = listado.getString("vte_mascotas_tipos_tipo_codigo");

                m = new Mascota(Integer.parseInt(codigo), Integer.parseInt(codigoPer), Integer.parseInt(codigoTipo), nombre2);
                mascotas.add(m);
            }

        } catch (SQLException ex) {
            System.out.println(ex);
        }
        return mascotas;
    }
    
    
    public ArrayList<Mascota> buscarListaMascota() {
        
        try {
            SQLr = "SELECT * FROM vte_mascotas ORDER BY 1";
            Connection con = conexion.conectar();
            PreparedStatement sentencia = con.prepareStatement(SQLr);
            listado = sentencia.executeQuery();
            while (listado.next()) {
                // Mientras haya registros en el ResultSet, iteramos y accedemos a los valores de las columnas
                String codigo = listado.getString("mas_codigo");
                String nombre2 = listado.getString("mas_nombre");
                String codigoPer = listado.getString("vte_personas_per_codigo");
                String codigoTipo = listado.getString("vte_mascotas_tipos_tipo_codigo");

                m = new Mascota(Integer.parseInt(codigo), Integer.parseInt(codigoPer), Integer.parseInt(codigoTipo), nombre2);
                mascotas.add(m);
            }

        } catch (SQLException ex) {
            System.out.println(ex);
        }
        return mascotas;
    }
    
    public int registrarMascota(String nombre,int perCod,int masTipo){
        int codigoAsignado = -1;//Codigo de la cita agendada
        try {
            
            SQLr = "INSERT INTO vte_mascotas VALUES (seq_mas_codigo.NEXTVAL,?, ?, ?)";
            Connection con = conexion.conectar();
            PreparedStatement sentencia = con.prepareStatement(SQLr);
            sentencia.setString(1, nombre);
            sentencia.setInt(2, perCod);
            sentencia.setInt(3, masTipo);
            
            int filasAfectadas = sentencia.executeUpdate();

            if (filasAfectadas > 0) {
                System.out.println("Se guardó correctamente la mascota");

                // Consulta para obtener el código asignado por la secuencia
                String sqlObtenerCodigo = "SELECT seq_mas_codigo.CURRVAL FROM DUAL";
                PreparedStatement sentenciaCodigo = con.prepareStatement(sqlObtenerCodigo);
                ResultSet resultado = sentenciaCodigo.executeQuery();

                if (resultado.next()) {
                    codigoAsignado = resultado.getInt(1);
                    System.out.println("Código asignado: " + codigoAsignado);
                }
                sentenciaCodigo.close();
            } else {
                System.out.println("No se pudo guardar la mascota.");
            }
            sentencia.close();
            con.close();
        } catch (SQLException ex) {
            System.out.println(ex);
        }
        return codigoAsignado;
    }
    
    public boolean actualizarMascota(Mascota mascota) {
        boolean llave = false;
        try {
            System.out.println("JJJJJJJJ"+mascota);
            SQLr = "UPDATE vte_mascotas SET mas_nombre=?, vte_personas_per_codigo=?, vte_mascotas_tipos_tipo_codigo=? WHERE mas_codigo=?";
            Connection con = conexion.conectar();
            PreparedStatement sentencia = con.prepareStatement(SQLr);

            sentencia.setString(1, mascota.getNombre());
            sentencia.setInt(2, mascota.getCodigo_per());
            sentencia.setInt(3, mascota.getCodigo_tipo());
            sentencia.setInt(4, mascota.getCodigo());

            int filasAfectadas = sentencia.executeUpdate();

            if (filasAfectadas > 0) {
                System.out.println("Se actualizó correctamente la mascota");
            } else {
                System.out.println("No se pudo actualizar la mascota");
            }
            sentencia.close();
            con.close();
            llave = true;
        } catch (SQLException ex) {
            System.out.println(ex);
        }
        return llave;
    }
    
    public boolean eliminarMascota(String nombre) {
        boolean llave = false;
        try {
            String SQLr = "DELETE  FROM vte_mascotas WHERE mas_nombre= ? ";
            Connection con = conexion.conectar();
            PreparedStatement sentencia = con.prepareStatement(SQLr);
            sentencia.setString(1, nombre);
            int filasAfectadas = sentencia.executeUpdate();
            if (filasAfectadas > 0) {
                System.out.println("Se eliminó correctamente la mascota " + nombre);
                llave = true;
            } else {
                System.out.println("No se pudo eliminar la mascota con el nombre " + nombre + " (No existe en la base de datos)");
            }
            sentencia.close();
            con.close();
        } catch (SQLException ex) {
            System.out.println(ex);
        }
        return llave;
    }
}
