package vista;

import modelo.Persona;
import controlador.*;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;

public class Seleccionar_Personal extends javax.swing.JFrame {


    private ControladorPersonal controlp;
    private Ventana_Citas vc;
    private Persona p;
    
    
    
    private Ventana_Usuarios vu;
     
    
    public Seleccionar_Personal() {
        initComponents();
        
    }
    public void setControlador(ControladorPersonal controlp,Ventana_Citas vc){
        this.controlp=controlp;
        this.vc=vc;
    }
    
    public void setControlador(ControladorPersonal controlp,Ventana_Usuarios vu){
        this.controlp=controlp;
        this.vu=vu;
    }
        
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnl_norte = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        pnl_sur = new javax.swing.JPanel();
        btn_cancelar = new javax.swing.JButton();
        btn_aceptar = new javax.swing.JButton();
        pnl_centro = new javax.swing.JPanel();
        pnl_centro_norte = new javax.swing.JPanel();
        txtfld_cedula = new javax.swing.JTextField();
        btn_buscar = new javax.swing.JButton();
        lbl_img_personal1 = new javax.swing.JLabel();
        lbl_img_personal2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        pnl_centro_centro = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblDatos = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        pnl_norte.setBackground(new java.awt.Color(4, 116, 190));
        pnl_norte.setForeground(new java.awt.Color(4, 116, 190));

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Rockwell Condensed", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Seleccione una opcion de busqueda e ingrese el valor a buscar: ");

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setFont(new java.awt.Font("Rockwell Condensed", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Buscar por: ");

        javax.swing.GroupLayout pnl_norteLayout = new javax.swing.GroupLayout(pnl_norte);
        pnl_norte.setLayout(pnl_norteLayout);
        pnl_norteLayout.setHorizontalGroup(
            pnl_norteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnl_norteLayout.createSequentialGroup()
                .addContainerGap(43, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(31, 31, 31))
            .addGroup(pnl_norteLayout.createSequentialGroup()
                .addGap(305, 305, 305)
                .addComponent(jLabel2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnl_norteLayout.setVerticalGroup(
            pnl_norteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_norteLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(16, Short.MAX_VALUE))
        );

        getContentPane().add(pnl_norte, java.awt.BorderLayout.PAGE_START);

        pnl_sur.setBackground(new java.awt.Color(255, 255, 255));
        pnl_sur.setForeground(new java.awt.Color(255, 255, 255));

        btn_cancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/cancelar.png"))); // NOI18N
        btn_cancelar.setText("CANCELAR");
        btn_cancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cancelarActionPerformed(evt);
            }
        });

        btn_aceptar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/aceptar.png"))); // NOI18N
        btn_aceptar.setText("ACEPTAR");
        btn_aceptar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_aceptarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pnl_surLayout = new javax.swing.GroupLayout(pnl_sur);
        pnl_sur.setLayout(pnl_surLayout);
        pnl_surLayout.setHorizontalGroup(
            pnl_surLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_surLayout.createSequentialGroup()
                .addContainerGap(176, Short.MAX_VALUE)
                .addComponent(btn_cancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(62, 62, 62)
                .addComponent(btn_aceptar, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(153, 153, 153))
        );
        pnl_surLayout.setVerticalGroup(
            pnl_surLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_surLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(pnl_surLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_aceptar, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_cancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(42, Short.MAX_VALUE))
        );

        getContentPane().add(pnl_sur, java.awt.BorderLayout.PAGE_END);

        pnl_centro.setLayout(new java.awt.BorderLayout());

        pnl_centro_norte.setBackground(new java.awt.Color(255, 255, 255));
        pnl_centro_norte.setForeground(new java.awt.Color(255, 255, 255));
        pnl_centro_norte.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtfld_cedula.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtfld_cedulaActionPerformed(evt);
            }
        });
        pnl_centro_norte.add(txtfld_cedula, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 40, 250, -1));

        btn_buscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/buscar.png"))); // NOI18N
        btn_buscar.setText("BUSCAR");
        btn_buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_buscarActionPerformed(evt);
            }
        });
        pnl_centro_norte.add(btn_buscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(296, 70, 127, 50));

        lbl_img_personal1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/personalV.png"))); // NOI18N
        pnl_centro_norte.add(lbl_img_personal1, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 20, 90, 70));

        lbl_img_personal2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/personalV.png"))); // NOI18N
        pnl_centro_norte.add(lbl_img_personal2, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 20, 90, 70));

        jLabel3.setFont(new java.awt.Font("Rockwell Condensed", 1, 14)); // NOI18N
        jLabel3.setText("Ingrese la cedula del veterinario:");
        pnl_centro_norte.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 0, 200, 30));

        pnl_centro.add(pnl_centro_norte, java.awt.BorderLayout.PAGE_START);

        pnl_centro_centro.setBackground(new java.awt.Color(255, 255, 255));
        pnl_centro_centro.setForeground(new java.awt.Color(255, 255, 255));

        tblDatos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "#Factura", "Fecha", "Apellido", "Tipo"
            }
        ));
        jScrollPane1.setViewportView(tblDatos);

        javax.swing.GroupLayout pnl_centro_centroLayout = new javax.swing.GroupLayout(pnl_centro_centro);
        pnl_centro_centro.setLayout(pnl_centro_centroLayout);
        pnl_centro_centroLayout.setHorizontalGroup(
            pnl_centro_centroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 714, Short.MAX_VALUE)
        );
        pnl_centro_centroLayout.setVerticalGroup(
            pnl_centro_centroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnl_centro_centroLayout.createSequentialGroup()
                .addGap(0, 20, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 321, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pnl_centro.add(pnl_centro_centro, java.awt.BorderLayout.CENTER);

        getContentPane().add(pnl_centro, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_buscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_buscarActionPerformed
        String datos=txtfld_cedula.getText();
        this.setTable(controlp.buscarPersonal(datos));
    }//GEN-LAST:event_btn_buscarActionPerformed

    
    private void txtfld_cedulaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtfld_cedulaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtfld_cedulaActionPerformed

    private void btn_aceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_aceptarActionPerformed
        int fila=tblDatos.getSelectedRow();//Saber que fila esta seleccionada
        
        if(vc != null){
            if(fila!=-1){
                System.out.println("Fila: "+fila);
                Object[] datosFila = new Object[tblDatos.getColumnCount()];
                for (int i = 0; i < tblDatos.getColumnCount(); i++) {
                    datosFila[i] = tblDatos.getValueAt(fila, i);
                }
                if(controlp.buscarPersonal(datosFila[0]+"").getTipo()=='V'){
                    vc.setPersona(controlp.buscarPersonal(datosFila[0] + ""));
                    vc.setMensaje1((controlp.buscarPersonal(datosFila[0] + "")).getNombres());
                    JOptionPane.showMessageDialog(null, "Se agrego correctamente al veterinario");
                    this.dispose();
                }else{
                    JOptionPane.showMessageDialog(null,"Solo se puede agregar veterinarios");
                }
            }else{
                JOptionPane.showMessageDialog(null,"Seleccione un Personal");
            }
        
        } else if (vu != null){
            if(fila!=-1){
                System.out.println("Fila: "+fila);
                Object[] datosFila = new Object[tblDatos.getColumnCount()];
                for (int i = 0; i < tblDatos.getColumnCount(); i++) {
                    datosFila[i] = tblDatos.getValueAt(fila, i);
                }
                
                 
                if(tblDatos.getValueAt(0, 3).equals('E')){
                    vu.setPersona(controlp.buscarPersonal(datosFila[0]+""));
                    vu.setMensaje1((controlp.buscarPersonal(datosFila[0]+"")).getNombres());
                    vu.setCodigoPersonal((controlp.buscarPersonal(datosFila[0]+"")).getCodigo());
                    JOptionPane.showMessageDialog(null,"Se agrego correctamente al personal");
                    this.dispose();
                } else{
                    JOptionPane.showMessageDialog(null, "No se puede agregar este personal");
                }


            }else{
                JOptionPane.showMessageDialog(null,"Seleccione un Personal");
            }
        }
    }//GEN-LAST:event_btn_aceptarActionPerformed

    private void btn_cancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cancelarActionPerformed
        this.dispose();
    }//GEN-LAST:event_btn_cancelarActionPerformed
    public void setTable(Persona p)
    {
        DefaultTableModel modeloTabla = new DefaultTableModel();
        tblDatos.setModel(modeloTabla);

        //modeloTabla.addColumn("Codigo");
        modeloTabla.addColumn("Cedula");
        modeloTabla.addColumn("Nombre");
        modeloTabla.addColumn("Apellido");
        //modeloTabla.addColumn("Direccion");
        //modeloTabla.addColumn("Telefono");
        //modeloTabla.addColumn("Correo");
        modeloTabla.addColumn("Tipo");
        //modeloTabla.addColumn("Estado");
        
        Object fila[]=new Object[4];
        //fila[0]=p.getCodigo();
        fila[0]=p.getCedula();
        fila[1]=p.getNombres();
        fila[2]=p.getApellidos();
        //fila[4]=p.getDireccion();
        //fila[5]=p.getTelefono();
        //fila[6]=p.getCorreo();
        fila[3]=p.getTipo();
        //fila[8]=p.getEstado();
        
        modeloTabla.addRow(fila);
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Seleccionar_Personal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Seleccionar_Personal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Seleccionar_Personal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Seleccionar_Personal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Seleccionar_Personal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_aceptar;
    private javax.swing.JButton btn_buscar;
    private javax.swing.JButton btn_cancelar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lbl_img_personal1;
    private javax.swing.JLabel lbl_img_personal2;
    private javax.swing.JPanel pnl_centro;
    private javax.swing.JPanel pnl_centro_centro;
    private javax.swing.JPanel pnl_centro_norte;
    private javax.swing.JPanel pnl_norte;
    private javax.swing.JPanel pnl_sur;
    private javax.swing.JTable tblDatos;
    private javax.swing.JTextField txtfld_cedula;
    // End of variables declaration//GEN-END:variables
}
