package vista;

import controlador.*;
import java.awt.Graphics;
import java.awt.Image;
import javax.swing.ImageIcon;
import modelo.Usuario;

public class Ventana_Menu_Principal extends javax.swing.JFrame {


    
    private Ventana_Inicio vi;
    private ControladorPersonal controlp;
    private ControladorMascota controlm;
    private ControladorTipoMascota controltm;
    private ControladorCita controlc;
    private Controlador_Clientes controlcli;
    private ControladorUsuario controlu;
    private ControladorServicio controls;
    private ControladorCabeceraFactura controlcf;
    private Usuario usuarioFactura;
    
    public Ventana_Menu_Principal() {
        initComponents();
        this.setLocation(0,0);
        this.setSize(1550,825);
    }
    
    public void setControladores(ControladorPersonal controlp,ControladorMascota controlm,
            ControladorTipoMascota controltm,ControladorCita controlc,Controlador_Clientes controlcli, 
            ControladorUsuario controlu, ControladorServicio controls, ControladorCabeceraFactura controlcf)
    {
        this.controlp=controlp;
        this.controlm=controlm;
        this.controltm=controltm;
        this.controlc=controlc;
        this.controlcli=controlcli;
        this.controlu=controlu;
        this.controls=controls;
        this.controlcf = controlcf;
    }
    
    public void aplicarPermisos(String permiso)
    {
        if(permiso.equals("G"))
        {
            mn_administracion.setEnabled(false);
            mn_administracion.setVisible(false);
            mnitm_citas.setVisible(false);
            mnitm_mascotas.setVisible(false);
            
        }else{
            mn_administracion.setEnabled(true);
            mn_administracion.setVisible(true);
            mnitm_citas.setVisible(true);
            mnitm_mascotas.setVisible(true);
        }
        
    }
    public void setVentanaInicio(Ventana_Inicio vi){
        this.vi=vi;
    }

    public void obtenerUsuario(Usuario usuarioFactura){
        this.usuarioFactura = usuarioFactura;
    }
        
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnl_principal = new javax.swing.JPanel();
        ImageIcon icon = new ImageIcon(getClass().getResource("/iconos/fondoprincipal3.png"));
        Image image = icon.getImage();
        dskpn_escritorio = new javax.swing.JDesktopPane(){
            public void paintComponent(Graphics g){
                g.drawImage(image,0,0,getWidth(),getHeight(),this);
            }
        };
        mn_opciones = new javax.swing.JMenuBar();
        mn_clinica = new javax.swing.JMenu();
        mnitm_citas = new javax.swing.JMenuItem();
        mnitm_clientes = new javax.swing.JMenuItem();
        mnitm_mascotas = new javax.swing.JMenuItem();
        mn_administracion = new javax.swing.JMenu();
        mnitm_servicios = new javax.swing.JMenuItem();
        mn_facturacion = new javax.swing.JMenu();
        mnitm_crear_factura = new javax.swing.JMenuItem();
        mnitm_eliminar_factura = new javax.swing.JMenuItem();
        mn_sesion = new javax.swing.JMenu();
        mnitm_cambiar_contrasenia = new javax.swing.JMenuItem();
        mnitm_cerrar_sesion = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1040, 720));
        setSize(new java.awt.Dimension(1040, 720));

        pnl_principal.setPreferredSize(new java.awt.Dimension(1000, 700));
        pnl_principal.setLayout(new java.awt.BorderLayout());

        javax.swing.GroupLayout dskpn_escritorioLayout = new javax.swing.GroupLayout(dskpn_escritorio);
        dskpn_escritorio.setLayout(dskpn_escritorioLayout);
        dskpn_escritorioLayout.setHorizontalGroup(
            dskpn_escritorioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 932, Short.MAX_VALUE)
        );
        dskpn_escritorioLayout.setVerticalGroup(
            dskpn_escritorioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 684, Short.MAX_VALUE)
        );

        pnl_principal.add(dskpn_escritorio, java.awt.BorderLayout.CENTER);

        getContentPane().add(pnl_principal, java.awt.BorderLayout.CENTER);

        mn_clinica.setText("CLINICA");

        mnitm_citas.setText("CITAS");
        mnitm_citas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnitm_citasActionPerformed(evt);
            }
        });
        mn_clinica.add(mnitm_citas);

        mnitm_clientes.setText("CLIENTES");
        mnitm_clientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnitm_clientesActionPerformed(evt);
            }
        });
        mn_clinica.add(mnitm_clientes);

        mnitm_mascotas.setText("MASCOTAS");
        mnitm_mascotas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnitm_mascotasActionPerformed(evt);
            }
        });
        mn_clinica.add(mnitm_mascotas);

        mn_opciones.add(mn_clinica);

        mn_administracion.setText("ADMINISTRACION");
        mn_administracion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mn_administracionActionPerformed(evt);
            }
        });

        mnitm_servicios.setText("SERVICIOS");
        mnitm_servicios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnitm_serviciosActionPerformed(evt);
            }
        });
        mn_administracion.add(mnitm_servicios);

        mn_opciones.add(mn_administracion);

        mn_facturacion.setText("FACTURACION");

        mnitm_crear_factura.setText("CREAR FACTURA");
        mnitm_crear_factura.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnitm_crear_facturaActionPerformed(evt);
            }
        });
        mn_facturacion.add(mnitm_crear_factura);

        mnitm_eliminar_factura.setText("ELIMINAR FACTURA");
        mnitm_eliminar_factura.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnitm_eliminar_facturaActionPerformed(evt);
            }
        });
        mn_facturacion.add(mnitm_eliminar_factura);

        mn_opciones.add(mn_facturacion);

        mn_sesion.setText("SESION");

        mnitm_cambiar_contrasenia.setText("CAMBIAR CONTRASEÑA");
        mnitm_cambiar_contrasenia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnitm_cambiar_contraseniaActionPerformed(evt);
            }
        });
        mn_sesion.add(mnitm_cambiar_contrasenia);

        mnitm_cerrar_sesion.setText("CERRAR SESION");
        mnitm_cerrar_sesion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnitm_cerrar_sesionActionPerformed(evt);
            }
        });
        mn_sesion.add(mnitm_cerrar_sesion);

        mn_opciones.add(mn_sesion);

        setJMenuBar(mn_opciones);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void mnitm_clientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnitm_clientesActionPerformed
        Ventana_Clientes vcl=new Ventana_Clientes();
        dskpn_escritorio.add(vcl);
        vcl.setControladorClientes(controlcli);
        vcl.setVisible(true);
    }//GEN-LAST:event_mnitm_clientesActionPerformed

    private void mnitm_cambiar_contraseniaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnitm_cambiar_contraseniaActionPerformed
        Ventana_CambiarContrasenia cc=new Ventana_CambiarContrasenia();
        dskpn_escritorio.add(cc);
        cc.setVisible(true);
    }//GEN-LAST:event_mnitm_cambiar_contraseniaActionPerformed

    private void mnitm_citasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnitm_citasActionPerformed
        Ventana_Citas vc=new Ventana_Citas();
        vc.setControladores(controlp,controlm,controltm,controlc);
        dskpn_escritorio.add(vc);
        vc.setVisible(true);
    }//GEN-LAST:event_mnitm_citasActionPerformed

    private void mnitm_crear_facturaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnitm_crear_facturaActionPerformed
        Ventana_Facturar vf=new Ventana_Facturar();
        vf.setControladores(controlp, controls, controlcf);
        dskpn_escritorio.add(vf);
        vf.obtenerUsuario(usuarioFactura); 
        vf.setVisible(true);
    }//GEN-LAST:event_mnitm_crear_facturaActionPerformed

    private void mnitm_mascotasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnitm_mascotasActionPerformed
        Ventana_Mascotas vm=new Ventana_Mascotas();
        vm.setControladorPersonal(controlp);
        vm.setControladorTipoMascota(controltm);
        vm.setControladorMascota(controlm);
        dskpn_escritorio.add(vm);
        vm.setVisible(true);
    }//GEN-LAST:event_mnitm_mascotasActionPerformed

    private void mn_administracionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mn_administracionActionPerformed
        
    }//GEN-LAST:event_mn_administracionActionPerformed

    private void mnitm_serviciosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnitm_serviciosActionPerformed
        Ventana_Servicios vs=new Ventana_Servicios();
        dskpn_escritorio.add(vs);
        vs.setVisible(true);
    }//GEN-LAST:event_mnitm_serviciosActionPerformed

    private void mnitm_eliminar_facturaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnitm_eliminar_facturaActionPerformed
        Ventana_Anular va2=new Ventana_Anular();
        va2.setControladores(controlcf, controlp);
        dskpn_escritorio.add(va2);
        va2.setVisible(true);
    }//GEN-LAST:event_mnitm_eliminar_facturaActionPerformed

    private void mnitm_cerrar_sesionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnitm_cerrar_sesionActionPerformed
        this.dispose();
        vi.setVisible(true);
        vi.vaciarCampos();
    }//GEN-LAST:event_mnitm_cerrar_sesionActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Ventana_Menu_Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Ventana_Menu_Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Ventana_Menu_Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Ventana_Menu_Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Ventana_Menu_Principal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JDesktopPane dskpn_escritorio;
    private javax.swing.JMenu mn_administracion;
    private javax.swing.JMenu mn_clinica;
    private javax.swing.JMenu mn_facturacion;
    private javax.swing.JMenuBar mn_opciones;
    private javax.swing.JMenu mn_sesion;
    private javax.swing.JMenuItem mnitm_cambiar_contrasenia;
    private javax.swing.JMenuItem mnitm_cerrar_sesion;
    private javax.swing.JMenuItem mnitm_citas;
    private javax.swing.JMenuItem mnitm_clientes;
    private javax.swing.JMenuItem mnitm_crear_factura;
    private javax.swing.JMenuItem mnitm_eliminar_factura;
    private javax.swing.JMenuItem mnitm_mascotas;
    private javax.swing.JMenuItem mnitm_servicios;
    private javax.swing.JPanel pnl_principal;
    // End of variables declaration//GEN-END:variables
}
