package vista;

import controlador.ControladorPersonal;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import modelo.Persona;


public class Seleccionar_Cliente extends javax.swing.JFrame {


    private ControladorPersonal controlp;
    private Ventana_Mascotas vm;
    
    private Ventana_Facturar vf;
    Persona persona;
    
    public Seleccionar_Cliente() {
        initComponents();
        this.setLocationRelativeTo(null);
    }

    public void setControlador(ControladorPersonal controlp,Ventana_Mascotas vm){
        this.controlp=controlp;
        this.vm=vm;
    }

    public void setControlador(ControladorPersonal controlp, Ventana_Facturar vf){
        this.controlp=controlp;
        this.vf=vf;
    }
        
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnl_norte = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        pnl_sur = new javax.swing.JPanel();
        btn_cancelar = new javax.swing.JButton();
        btn_aceptar = new javax.swing.JButton();
        pnl_centro = new javax.swing.JPanel();
        pnl_centro_norte = new javax.swing.JPanel();
        txtfld_cedula = new javax.swing.JTextField();
        btn_buscar = new javax.swing.JButton();
        lbl_img_cliente2 = new javax.swing.JLabel();
        lbl_img_cliente1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        pnl_centro_centro = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblDatos = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        pnl_norte.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(4, 116, 190));
        jPanel1.setForeground(new java.awt.Color(4, 116, 190));

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Rockwell Condensed", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Seleccione una opcion de busqueda e ingrese el valor a buscar: ");

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setFont(new java.awt.Font("Rockwell Condensed", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Buscar por: ");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(14, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addContainerGap())
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(282, 282, 282)
                .addComponent(jLabel2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(21, Short.MAX_VALUE))
        );

        pnl_norte.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 660, -1));

        getContentPane().add(pnl_norte, java.awt.BorderLayout.PAGE_START);

        pnl_sur.setBackground(new java.awt.Color(255, 255, 255));
        pnl_sur.setForeground(new java.awt.Color(255, 255, 255));

        btn_cancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/cancelar.png"))); // NOI18N
        btn_cancelar.setText("CANCELAR");
        btn_cancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cancelarActionPerformed(evt);
            }
        });

        btn_aceptar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/aceptar.png"))); // NOI18N
        btn_aceptar.setText("ACEPTAR");
        btn_aceptar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_aceptarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pnl_surLayout = new javax.swing.GroupLayout(pnl_sur);
        pnl_sur.setLayout(pnl_surLayout);
        pnl_surLayout.setHorizontalGroup(
            pnl_surLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_surLayout.createSequentialGroup()
                .addContainerGap(158, Short.MAX_VALUE)
                .addComponent(btn_cancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32)
                .addComponent(btn_aceptar, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(145, 145, 145))
        );
        pnl_surLayout.setVerticalGroup(
            pnl_surLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_surLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(pnl_surLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_aceptar, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_cancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(16, Short.MAX_VALUE))
        );

        getContentPane().add(pnl_sur, java.awt.BorderLayout.PAGE_END);

        pnl_centro.setLayout(new java.awt.BorderLayout());

        pnl_centro_norte.setBackground(new java.awt.Color(255, 255, 255));
        pnl_centro_norte.setForeground(new java.awt.Color(255, 255, 255));
        pnl_centro_norte.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        pnl_centro_norte.add(txtfld_cedula, new org.netbeans.lib.awtextra.AbsoluteConstraints(212, 40, 250, -1));

        btn_buscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/buscar.png"))); // NOI18N
        btn_buscar.setText("BUSCAR");
        btn_buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_buscarActionPerformed(evt);
            }
        });
        pnl_centro_norte.add(btn_buscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(268, 70, 135, 42));

        lbl_img_cliente2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/clienteV.png"))); // NOI18N
        pnl_centro_norte.add(lbl_img_cliente2, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 0, 90, 110));

        lbl_img_cliente1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/clienteV.png"))); // NOI18N
        pnl_centro_norte.add(lbl_img_cliente1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 0, 90, 110));

        jLabel3.setFont(new java.awt.Font("Rockwell Condensed", 1, 18)); // NOI18N
        jLabel3.setText("Ingrese la cedula del cliente");
        pnl_centro_norte.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 10, 220, 30));

        pnl_centro.add(pnl_centro_norte, java.awt.BorderLayout.PAGE_START);

        pnl_centro_centro.setBackground(new java.awt.Color(255, 255, 255));
        pnl_centro_centro.setForeground(new java.awt.Color(255, 255, 255));

        tblDatos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Cedula", "Nombre", "Apellido", "Tipo"
            }
        ));
        jScrollPane2.setViewportView(tblDatos);

        javax.swing.GroupLayout pnl_centro_centroLayout = new javax.swing.GroupLayout(pnl_centro_centro);
        pnl_centro_centro.setLayout(pnl_centro_centroLayout);
        pnl_centro_centroLayout.setHorizontalGroup(
            pnl_centro_centroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 660, Short.MAX_VALUE)
        );
        pnl_centro_centroLayout.setVerticalGroup(
            pnl_centro_centroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_centro_centroLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 403, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pnl_centro.add(pnl_centro_centro, java.awt.BorderLayout.CENTER);

        getContentPane().add(pnl_centro, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_buscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_buscarActionPerformed
        String datos=txtfld_cedula.getText();
        persona = controlp.buscarPersonal(datos);
        this.setTable(persona);
    }//GEN-LAST:event_btn_buscarActionPerformed

    private void btn_cancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cancelarActionPerformed
        txtfld_cedula.setText("");
        this.dispose();
    }//GEN-LAST:event_btn_cancelarActionPerformed

    private void btn_aceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_aceptarActionPerformed
        int fila=tblDatos.getSelectedRow();//Saber que fila esta seleccionada
        
        if(vf != null){
            if(fila!=-1){
                System.out.println("Fila: "+fila);
                Object[] datosFila = new Object[tblDatos.getColumnCount()];
                for (int i = 0; i < tblDatos.getColumnCount(); i++) {
                    datosFila[i] = tblDatos.getValueAt(fila, i);
                }

                String tipoPersona = tblDatos.getValueAt(fila, 3).toString();
                
                if("C".equals(tipoPersona)){
                    vf.obtenerCliente(persona);
                    JOptionPane.showMessageDialog(null,"Se agrego correctamente al Cliente");
                    
                } else{
                    JOptionPane.showMessageDialog(null,"Este personal no es un cliente");
                }

                this.dispose();
                
            }else{
                JOptionPane.showMessageDialog(null,"Seleccione un Personal");
            }
                        
        } else if(vm != null){
            if(fila!=-1){
                System.out.println("Fila: "+fila);
                Object[] datosFila = new Object[tblDatos.getColumnCount()];
                
                for (int i = 0; i < tblDatos.getColumnCount(); i++) {
                    datosFila[i] = tblDatos.getValueAt(fila, i);
                }
                
                vm.setCedulaCliente(datosFila[0]+"");
                vm.setMensajeDuenio(datosFila[1]+"");
                
                JOptionPane.showMessageDialog(null,"Se agrego correctamente al Veterinario");
                this.dispose();
            }else{
                JOptionPane.showMessageDialog(null,"Seleccione un Personal");
            }
        }
    }//GEN-LAST:event_btn_aceptarActionPerformed

    public void setTable(Persona p)
    {
        System.out.println("PERSONA: "+p);
        DefaultTableModel modeloTabla = new DefaultTableModel();
        tblDatos.setModel(modeloTabla);

        modeloTabla.addColumn("Cedula");
        modeloTabla.addColumn("Nombre");
        modeloTabla.addColumn("Apellido");
        modeloTabla.addColumn("Tipo");

        if (p != null) {
            Object fila[] = new Object[4];
            fila[0] = p.getCedula();
            fila[1] = p.getNombres();
            fila[2] = p.getApellidos();
            fila[3] = p.getTipo();

            modeloTabla.addRow(fila);
        }

        // Ajustar el modelo de renderizado para hacer los datos visibles
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(DefaultTableCellRenderer.CENTER);
        tblDatos.setDefaultRenderer(Object.class, centerRenderer);

        // Ajustar el tamaño de las columnas
        tblDatos.setAutoResizeMode(tblDatos.AUTO_RESIZE_ALL_COLUMNS);
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Seleccionar_Cliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Seleccionar_Cliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Seleccionar_Cliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Seleccionar_Cliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Seleccionar_Cliente().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_aceptar;
    private javax.swing.JButton btn_buscar;
    private javax.swing.JButton btn_cancelar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lbl_img_cliente1;
    private javax.swing.JLabel lbl_img_cliente2;
    private javax.swing.JPanel pnl_centro;
    private javax.swing.JPanel pnl_centro_centro;
    private javax.swing.JPanel pnl_centro_norte;
    private javax.swing.JPanel pnl_norte;
    private javax.swing.JPanel pnl_sur;
    private javax.swing.JTable tblDatos;
    private javax.swing.JTextField txtfld_cedula;
    // End of variables declaration//GEN-END:variables
}
