package vista;

import controlador.ControladorPersonal;
import javax.swing.JOptionPane;
import modelo.*;
import controlador.*;
import dao.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import javax.swing.table.DefaultTableModel;

public class Ventana_Usuarios extends javax.swing.JInternalFrame {

    private ControladorUsuario controlu;
    private ControladorPersonal controlp;
    Usuario usuario;
    
    private Persona p;
    int condigoPersonal;
    
    Seleccionar_Personal sp;
    
    public void setMensaje1(String nombre){
        lbl_texto3.setText("Se selecciono al personal: "+nombre);
    }
    
    public void setCodigoPersonal(int codigo){
        this.condigoPersonal = codigo;
    }
    
    public void setPersona(Persona p){
        System.out.println("Persona: "+p);
        this.p=p;
    }
       
    public void obtenerUsuario(Usuario usuario){
        this.usuario = usuario;
    }
    
    public Ventana_Usuarios() {
        initComponents();
        obtenerUsuarios();
    }


    public void setControladores(ControladorPersonal controlp, ControladorUsuario controlu){
        this.controlp=controlp;
        this.controlu=controlu;
    }
        
    public void obtenerUsuarios(){
        ControladorPersonal controlp2 = new ControladorPersonal();
        DefaultTableModel modeloTabla = new DefaultTableModel();
        jTable1.setModel(modeloTabla); 
      
        
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try {
            Conexion con = new Conexion();
            Connection conexion = con.conectar();
            
            ps = conexion.prepareStatement("SELECT * FROM vte_usuarios"); 
            rs = ps.executeQuery();
            
            modeloTabla.addColumn("Codigo");
            modeloTabla.addColumn("Usuario");
            modeloTabla.addColumn("Contraseña");
            modeloTabla.addColumn("Encargo");
            modeloTabla.addColumn("Persona");
             
            ResultSetMetaData rsMD = rs.getMetaData(); //Se obtienen todos los datos que se obtubieron en las consulta
            int cantidadColumnas = rsMD.getColumnCount(); //Se obtiene la cantidad de columnas
            
            int anchos[] = {50, 150, 50, 70, 50, 50};
            
            for(int i=0; i<cantidadColumnas; i++){
                jTable1.getColumnModel().getColumn(i).setPreferredWidth(anchos[i]);
                
            }
            
            while(rs.next()){
                Object fila[] = new Object[cantidadColumnas];
                
                for(int i=0; i<cantidadColumnas; i++){
                    fila[i] = rs.getObject(i+1);
                    
                    if(i==4){
                        
                        Persona persona = controlp2.buscarPersona2(rs.getObject(i+1).toString());
                        fila[i] = persona.getNombres() + " " + persona.getApellidos();
                    }
                }
                
                modeloTabla.addRow(fila); 
                
            }
            
        } catch (Exception e) {
            System.err.println("Error, " + e);
            
        }
    }
    
    public void actualizarTabla(Usuario usuario, Persona persona){
        
        DefaultTableModel modeloTabla = new DefaultTableModel();
        jTable1.setModel(modeloTabla);

        modeloTabla.addColumn("id");
        modeloTabla.addColumn("Usuario");
        modeloTabla.addColumn("Contraseña");
        modeloTabla.addColumn("Estado");
        modeloTabla.addColumn("Encargo");
        modeloTabla.addColumn("Persona");
        
        Object fila[]=new Object[6];
        
        fila[0]=usuario.getCodigo();
        fila[1]=usuario.getUsername();
        fila[2]=usuario.getContrasenia();
        fila[3]=usuario.getEstado();
        fila[4]=usuario.getPermiso();
        fila[5]=persona.getNombres();
        
        modeloTabla.addRow(fila);
    }
    
    public void obtenerUsuario(String[] datosUsuario){
        
        DefaultTableModel modeloTabla = new DefaultTableModel();
        jTable1.setModel(modeloTabla);

        modeloTabla.addColumn("id");
        modeloTabla.addColumn("Usuario");
        modeloTabla.addColumn("Contraseña");
        modeloTabla.addColumn("Estado");
        modeloTabla.addColumn("Encargo");
        modeloTabla.addColumn("Persona");
        
        Object fila[]=new Object[6];
        
        fila[0]=datosUsuario[0];
        fila[1]=datosUsuario[1];
        fila[2]=datosUsuario[2];
        fila[3]=datosUsuario[3];
        fila[4]="-";
        fila[5]=datosUsuario[4];
        
        modeloTabla.addRow(fila);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnl_este = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        pnl_principal = new javax.swing.JPanel();
        pnl_norte = new javax.swing.JPanel();
        lbl_texto1 = new javax.swing.JLabel();
        lbl_texto2 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        pnl_centro = new javax.swing.JPanel();
        pnl_centro_norte = new javax.swing.JPanel();
        lbl_texto4 = new javax.swing.JLabel();
        lbl_texto6 = new javax.swing.JLabel();
        lbl_texto7 = new javax.swing.JLabel();
        txtfld_nombre_usuario = new javax.swing.JTextField();
        lbl_texto8 = new javax.swing.JLabel();
        cmbbx_estado = new javax.swing.JComboBox<>();
        cmbbx_encargo = new javax.swing.JComboBox<>();
        btn_seleccionar_personal = new javax.swing.JButton();
        lbl_texto3 = new javax.swing.JLabel();
        pwdfld_contrasenia = new javax.swing.JPasswordField();
        pwdfld_contrasenia2 = new javax.swing.JPasswordField();
        lbl_texto5 = new javax.swing.JLabel();
        tglbtn_mostrar1 = new javax.swing.JToggleButton();
        tglbtn_mostrar2 = new javax.swing.JToggleButton();
        pnl_centro_centro = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        pnl_centro_sur = new javax.swing.JPanel();
        btn_registrar = new javax.swing.JButton();
        btn_buscar = new javax.swing.JButton();
        btn_modificar = new javax.swing.JButton();
        btn_eliminar = new javax.swing.JButton();
        btn_cancelar = new javax.swing.JButton();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/fondo6.png"))); // NOI18N

        javax.swing.GroupLayout pnl_esteLayout = new javax.swing.GroupLayout(pnl_este);
        pnl_este.setLayout(pnl_esteLayout);
        pnl_esteLayout.setHorizontalGroup(
            pnl_esteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        pnl_esteLayout.setVerticalGroup(
            pnl_esteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        getContentPane().add(pnl_este, java.awt.BorderLayout.LINE_START);

        pnl_principal.setLayout(new java.awt.BorderLayout());

        pnl_norte.setBackground(new java.awt.Color(4, 116, 190));
        pnl_norte.setForeground(new java.awt.Color(4, 116, 190));

        lbl_texto1.setBackground(new java.awt.Color(255, 255, 255));
        lbl_texto1.setFont(new java.awt.Font("Rockwell Condensed", 1, 24)); // NOI18N
        lbl_texto1.setForeground(new java.awt.Color(255, 255, 255));
        lbl_texto1.setText("!BIENVENIDO!");

        lbl_texto2.setBackground(new java.awt.Color(255, 255, 255));
        lbl_texto2.setFont(new java.awt.Font("Rockwell Condensed", 1, 18)); // NOI18N
        lbl_texto2.setForeground(new java.awt.Color(255, 255, 255));
        lbl_texto2.setText("Ingrese la informacion o la seleccione una opcion para la administracion de los Usuarios");

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/personalV.png"))); // NOI18N

        javax.swing.GroupLayout pnl_norteLayout = new javax.swing.GroupLayout(pnl_norte);
        pnl_norte.setLayout(pnl_norteLayout);
        pnl_norteLayout.setHorizontalGroup(
            pnl_norteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_norteLayout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(pnl_norteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbl_texto2)
                    .addComponent(lbl_texto1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 26, Short.MAX_VALUE)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(69, 69, 69))
        );
        pnl_norteLayout.setVerticalGroup(
            pnl_norteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_norteLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(pnl_norteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(pnl_norteLayout.createSequentialGroup()
                        .addComponent(lbl_texto1)
                        .addGap(18, 18, 18)
                        .addComponent(lbl_texto2)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pnl_principal.add(pnl_norte, java.awt.BorderLayout.PAGE_START);

        pnl_centro.setLayout(new java.awt.BorderLayout());

        pnl_centro_norte.setBackground(new java.awt.Color(255, 255, 255));
        pnl_centro_norte.setForeground(new java.awt.Color(255, 255, 255));

        lbl_texto4.setFont(new java.awt.Font("Rockwell Condensed", 1, 14)); // NOI18N
        lbl_texto4.setText("Nombre del Usuario*");

        lbl_texto6.setFont(new java.awt.Font("Rockwell Condensed", 1, 14)); // NOI18N
        lbl_texto6.setText("Confirmar Contraseña*");

        lbl_texto7.setFont(new java.awt.Font("Rockwell Condensed", 1, 14)); // NOI18N
        lbl_texto7.setText("Encargo*");

        lbl_texto8.setFont(new java.awt.Font("Rockwell Condensed", 1, 14)); // NOI18N
        lbl_texto8.setText("Estado*");

        cmbbx_estado.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Activo", "Inactivo" }));

        cmbbx_encargo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "General", " " }));

        btn_seleccionar_personal.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/cliente.png"))); // NOI18N
        btn_seleccionar_personal.setText("SELECCIONE AL PERSONAL");
        btn_seleccionar_personal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_seleccionar_personalActionPerformed(evt);
            }
        });

        lbl_texto3.setFont(new java.awt.Font("Rockwell Condensed", 1, 14)); // NOI18N
        lbl_texto3.setText("Ningun Personal Seleccionado*");

        lbl_texto5.setFont(new java.awt.Font("Rockwell Condensed", 1, 14)); // NOI18N
        lbl_texto5.setText("Contraseña*");

        tglbtn_mostrar1.setText("Mostrar");
        tglbtn_mostrar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tglbtn_mostrar1ActionPerformed(evt);
            }
        });

        tglbtn_mostrar2.setText("Mostrar");
        tglbtn_mostrar2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tglbtn_mostrar2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pnl_centro_norteLayout = new javax.swing.GroupLayout(pnl_centro_norte);
        pnl_centro_norte.setLayout(pnl_centro_norteLayout);
        pnl_centro_norteLayout.setHorizontalGroup(
            pnl_centro_norteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_centro_norteLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(pnl_centro_norteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnl_centro_norteLayout.createSequentialGroup()
                        .addGroup(pnl_centro_norteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtfld_nombre_usuario, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lbl_texto4)
                            .addComponent(lbl_texto7)
                            .addComponent(cmbbx_encargo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(pnl_centro_norteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnl_centro_norteLayout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(lbl_texto5))
                            .addGroup(pnl_centro_norteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(cmbbx_estado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(lbl_texto8))
                            .addComponent(pwdfld_contrasenia, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tglbtn_mostrar1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(pnl_centro_norteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lbl_texto6)
                            .addGroup(pnl_centro_norteLayout.createSequentialGroup()
                                .addComponent(pwdfld_contrasenia2, javax.swing.GroupLayout.PREFERRED_SIZE, 221, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(tglbtn_mostrar2))))
                    .addGroup(pnl_centro_norteLayout.createSequentialGroup()
                        .addComponent(btn_seleccionar_personal, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(33, 33, 33)
                        .addComponent(lbl_texto3)))
                .addContainerGap(19, Short.MAX_VALUE))
        );
        pnl_centro_norteLayout.setVerticalGroup(
            pnl_centro_norteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_centro_norteLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnl_centro_norteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_seleccionar_personal, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_texto3))
                .addGap(18, 18, 18)
                .addGroup(pnl_centro_norteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbl_texto4)
                    .addGroup(pnl_centro_norteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lbl_texto5)
                        .addComponent(lbl_texto6)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnl_centro_norteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pwdfld_contrasenia2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(pnl_centro_norteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txtfld_nombre_usuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(pwdfld_contrasenia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(tglbtn_mostrar1)
                        .addComponent(tglbtn_mostrar2)))
                .addGap(24, 24, 24)
                .addGroup(pnl_centro_norteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_texto7)
                    .addComponent(lbl_texto8))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnl_centro_norteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cmbbx_encargo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbbx_estado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 32, Short.MAX_VALUE))
        );

        pnl_centro.add(pnl_centro_norte, java.awt.BorderLayout.PAGE_START);

        pnl_centro_centro.setBackground(new java.awt.Color(255, 255, 255));
        pnl_centro_centro.setForeground(new java.awt.Color(255, 255, 255));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Id", "Usuario", "Contraseña", "Encargo", "Estado", "Persona"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout pnl_centro_centroLayout = new javax.swing.GroupLayout(pnl_centro_centro);
        pnl_centro_centro.setLayout(pnl_centro_centroLayout);
        pnl_centro_centroLayout.setHorizontalGroup(
            pnl_centro_centroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnl_centro_centroLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 860, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        pnl_centro_centroLayout.setVerticalGroup(
            pnl_centro_centroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 122, Short.MAX_VALUE)
        );

        pnl_centro.add(pnl_centro_centro, java.awt.BorderLayout.CENTER);

        pnl_centro_sur.setBackground(new java.awt.Color(255, 255, 255));
        pnl_centro_sur.setForeground(new java.awt.Color(255, 255, 255));

        btn_registrar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/registrar.png"))); // NOI18N
        btn_registrar.setText("REGISTRAR");
        btn_registrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_registrarActionPerformed(evt);
            }
        });

        btn_buscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/buscar.png"))); // NOI18N
        btn_buscar.setText("BUSCAR");
        btn_buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_buscarActionPerformed(evt);
            }
        });

        btn_modificar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/desbloquear_1.png"))); // NOI18N
        btn_modificar.setText("Admin");
        btn_modificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_modificarActionPerformed(evt);
            }
        });

        btn_eliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/bloquear_1.png"))); // NOI18N
        btn_eliminar.setText("General");
        btn_eliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_eliminarActionPerformed(evt);
            }
        });

        btn_cancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/cancelar.png"))); // NOI18N
        btn_cancelar.setText("CANCELAR");
        btn_cancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cancelarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pnl_centro_surLayout = new javax.swing.GroupLayout(pnl_centro_sur);
        pnl_centro_sur.setLayout(pnl_centro_surLayout);
        pnl_centro_surLayout.setHorizontalGroup(
            pnl_centro_surLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_centro_surLayout.createSequentialGroup()
                .addContainerGap(41, Short.MAX_VALUE)
                .addComponent(btn_registrar, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btn_buscar, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btn_modificar, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btn_eliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btn_cancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35))
        );
        pnl_centro_surLayout.setVerticalGroup(
            pnl_centro_surLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_centro_surLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(pnl_centro_surLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE, false)
                    .addComponent(btn_registrar, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_buscar, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_modificar, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_eliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_cancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(27, Short.MAX_VALUE))
        );

        pnl_centro.add(pnl_centro_sur, java.awt.BorderLayout.PAGE_END);

        pnl_principal.add(pnl_centro, java.awt.BorderLayout.CENTER);

        getContentPane().add(pnl_principal, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tglbtn_mostrar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tglbtn_mostrar1ActionPerformed
        if(tglbtn_mostrar1.isSelected()) 
        {
            pwdfld_contrasenia.setEchoChar((char) 0); // Mostrar el texto plano
        }else{
            pwdfld_contrasenia.setEchoChar('*'); // Ocultar el texto
        }
    }//GEN-LAST:event_tglbtn_mostrar1ActionPerformed

    private void tglbtn_mostrar2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tglbtn_mostrar2ActionPerformed
        if(tglbtn_mostrar2.isSelected()) 
        {
            pwdfld_contrasenia2.setEchoChar((char) 0); // Mostrar el texto plano
        }else{
            pwdfld_contrasenia2.setEchoChar('*'); // Ocultar el texto
        }
    }//GEN-LAST:event_tglbtn_mostrar2ActionPerformed

    private void btn_seleccionar_personalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_seleccionar_personalActionPerformed
        sp=new Seleccionar_Personal();
        sp.setControlador(controlp,this);
        //sp.setDefaultCloseOperatison();
        sp.setLocationRelativeTo(null);
        sp.setVisible(true);
    }//GEN-LAST:event_btn_seleccionar_personalActionPerformed

    private void btn_buscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_buscarActionPerformed
        Buscar_Usuario bu=new Buscar_Usuario();
        bu.setControlador(controlu, this); 
        bu.setVisible(true);
    }//GEN-LAST:event_btn_buscarActionPerformed

    private void btn_registrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_registrarActionPerformed
        String userName = txtfld_nombre_usuario.getText();
        char[] arrayPassword = pwdfld_contrasenia.getPassword();
        char[] arrayPasswordConfirm = pwdfld_contrasenia2.getPassword();
        String password = new String(arrayPassword);
        String passwordConfirm = new String(arrayPasswordConfirm);
        String encargo = cmbbx_encargo.getSelectedItem().toString();
        String estado = cmbbx_estado.getSelectedItem().toString();
        encargo = encargo.equals("Administrador") ? "A" : "G";
        estado = estado.equals("Activo") ? "A" : "I";
        
        if(!password.equals(passwordConfirm)){
            JOptionPane.showMessageDialog(null, "Las contrasenias no coinciden");
        
        } else {
            Usuario usuario = new Usuario(this.condigoPersonal, userName, password, encargo.charAt(0), estado.charAt(0));

            if (controlu.registrarUsuario(usuario)){
                JOptionPane.showMessageDialog(null,"Usuario registrado correctamente");
                this.actualizarTabla(usuario, p);
                obtenerUsuarios();
                //this.limpiarFormulario();
            } else { 
                JOptionPane.showMessageDialog(null,"Error al registrar el usuario");
            }
        }
    }//GEN-LAST:event_btn_registrarActionPerformed

    private void btn_modificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_modificarActionPerformed
        String codigo = String.valueOf(jTable1.getValueAt(0,0).toString());
        
        if (controlu.activarUsuario(Integer.parseInt(codigo))){
            JOptionPane.showMessageDialog(null, "Usuario asignado como administrador");
            obtenerUsuarios();
        } else{
            JOptionPane.showMessageDialog(null, "Error");
        }
    }//GEN-LAST:event_btn_modificarActionPerformed

    private void btn_eliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_eliminarActionPerformed
        String codigo = String.valueOf(jTable1.getValueAt(0,0).toString());
        
        if (controlu.desactivarUsuario(Integer.parseInt(codigo))){
            JOptionPane.showMessageDialog(null, "Usuario asignado como general");
            obtenerUsuarios();
        } else{
            JOptionPane.showMessageDialog(null, "Error");
        }
    }//GEN-LAST:event_btn_eliminarActionPerformed

    private void btn_cancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cancelarActionPerformed
        this.dispose();
    }//GEN-LAST:event_btn_cancelarActionPerformed


    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_buscar;
    private javax.swing.JButton btn_cancelar;
    private javax.swing.JButton btn_eliminar;
    private javax.swing.JButton btn_modificar;
    private javax.swing.JButton btn_registrar;
    private javax.swing.JButton btn_seleccionar_personal;
    private javax.swing.JComboBox<String> cmbbx_encargo;
    private javax.swing.JComboBox<String> cmbbx_estado;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel lbl_texto1;
    private javax.swing.JLabel lbl_texto2;
    private javax.swing.JLabel lbl_texto3;
    private javax.swing.JLabel lbl_texto4;
    private javax.swing.JLabel lbl_texto5;
    private javax.swing.JLabel lbl_texto6;
    private javax.swing.JLabel lbl_texto7;
    private javax.swing.JLabel lbl_texto8;
    private javax.swing.JPanel pnl_centro;
    private javax.swing.JPanel pnl_centro_centro;
    private javax.swing.JPanel pnl_centro_norte;
    private javax.swing.JPanel pnl_centro_sur;
    private javax.swing.JPanel pnl_este;
    private javax.swing.JPanel pnl_norte;
    private javax.swing.JPanel pnl_principal;
    private javax.swing.JPasswordField pwdfld_contrasenia;
    private javax.swing.JPasswordField pwdfld_contrasenia2;
    private javax.swing.JToggleButton tglbtn_mostrar1;
    private javax.swing.JToggleButton tglbtn_mostrar2;
    private javax.swing.JTextField txtfld_nombre_usuario;
    // End of variables declaration//GEN-END:variables
}
