package vista;

import controlador.*;
import dao.UsuarioDao;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;


public class Inicio {


    public static void main(String[] args) 
    {
        //INSTACICIAS DE LA CLASES
        Ventana_Inicio vi=new Ventana_Inicio();
        ControladorUsuario controlu=new ControladorUsuario();
        ControladorPersonal controlp=new ControladorPersonal();
        ControladorMascota controlm=new ControladorMascota();
        ControladorCita controlc=new ControladorCita();
        ControladorTipoMascota controltm=new ControladorTipoMascota();
        Controlador_Clientes controlcli=new Controlador_Clientes();
        ControladorServicio controls = new ControladorServicio();
        ControladorCabeceraFactura controlcf = new ControladorCabeceraFactura();
        
        UsuarioDao usuDao=new UsuarioDao();
        //PersonalDao perDao=new PersonalDao();
        
        //controlp.setPersonalDao(perDao);
        
        //SETTEO DE LAS INSTACIAS
        vi.setControladores(controlu,controlp,controlm,controlc,controltm,controlcli, controls, controlcf);
        
        controlu.setUsuarioDao(usuDao);
        //controlp.setPersonalDao(perDao);
        
        
        
        vi.setVisible(true);
    }
}
