package vista;

import controlador.ControladorServicio;
import javax.swing.table.DefaultTableModel;
import modelo.Servicio;

import dao.Conexion;

import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSetMetaData;
import javax.swing.JOptionPane;


public class Ventana_Servicios extends javax.swing.JInternalFrame {

    int codigo;
    
    ControladorServicio controladors = new ControladorServicio();
    
    public void obtenerServicio(Servicio servicio){
        
        DefaultTableModel modeloTabla = new DefaultTableModel();
        jTable1.setModel(modeloTabla);

        modeloTabla.addColumn("Codigo");
        modeloTabla.addColumn("Nombre");
        modeloTabla.addColumn("Precio");
        modeloTabla.addColumn("iva");
        
        Object fila[]=new Object[4];
        
        fila[0]=servicio.getCodigo();
        fila[1]=servicio.getNombre();
        fila[2]=servicio.getPrecio();
        fila[3]=servicio.getIva();
        
        modeloTabla.addRow(fila);
    }
    
    public void obtenerServicios(){
        DefaultTableModel modeloTabla = new DefaultTableModel();
        jTable1.setModel(modeloTabla); 
      
        
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try {
            Conexion con = new Conexion();
            Connection conexion = con.conectar();
            
            ps = conexion.prepareStatement("SELECT * FROM vte_servicios"); 
            rs = ps.executeQuery();
            
            modeloTabla.addColumn("Codigo");
            modeloTabla.addColumn("Nombre");
            modeloTabla.addColumn("Precio");
            modeloTabla.addColumn("iva");
        
             
            ResultSetMetaData rsMD = rs.getMetaData(); //Se obtienen todos los datos que se obtubieron en las consulta
            int cantidadColumnas = rsMD.getColumnCount(); //Se obtiene la cantidad de columnas
            
            int anchos[] = {50, 150, 50, 70};
            
            for(int i=0; i<cantidadColumnas; i++){
                jTable1.getColumnModel().getColumn(i).setPreferredWidth(anchos[i]);
                
            }
            
            while(rs.next()){
                Object fila[] = new Object[cantidadColumnas];
                
                for(int i=0; i<cantidadColumnas; i++){
                    fila[i] = rs.getObject(i+1);
                }
                
                modeloTabla.addRow(fila); 
                
            }
            
        } catch (Exception e) {
            System.err.println("Error, " + e);
            
        }
    }

    public Ventana_Servicios() {
        initComponents();
        obtenerServicios();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnl_este = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        pnl_principal = new javax.swing.JPanel();
        pnl_norte = new javax.swing.JPanel();
        lbl_texto1 = new javax.swing.JLabel();
        lbl_texto2 = new javax.swing.JLabel();
        pnl_centro = new javax.swing.JPanel();
        pnl_centro_norte = new javax.swing.JPanel();
        lbl_texto3 = new javax.swing.JLabel();
        lbl_texto4 = new javax.swing.JLabel();
        lbl_texto5 = new javax.swing.JLabel();
        txtfld_nombre_servicio = new javax.swing.JTextField();
        txtfld_precio = new javax.swing.JTextField();
        lbl_texto6 = new javax.swing.JLabel();
        cmbbx_iva = new javax.swing.JComboBox<>();
        cmbbx_estado = new javax.swing.JComboBox<>();
        pnl_centro_centro = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        pnl_centro_sur = new javax.swing.JPanel();
        btn_registrar = new javax.swing.JButton();
        btn_buscar = new javax.swing.JButton();
        btn_modificar = new javax.swing.JButton();
        btn_eliminar = new javax.swing.JButton();
        btn_cancelar = new javax.swing.JButton();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);

        pnl_este.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/fondo6.png"))); // NOI18N
        jLabel1.setText("jLabel1");
        pnl_este.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 100, 570));

        getContentPane().add(pnl_este, java.awt.BorderLayout.LINE_START);

        pnl_principal.setLayout(new java.awt.BorderLayout());

        pnl_norte.setBackground(new java.awt.Color(4, 116, 190));
        pnl_norte.setForeground(new java.awt.Color(4, 116, 190));

        lbl_texto1.setBackground(new java.awt.Color(255, 255, 255));
        lbl_texto1.setFont(new java.awt.Font("Rockwell Condensed", 1, 24)); // NOI18N
        lbl_texto1.setForeground(new java.awt.Color(255, 255, 255));
        lbl_texto1.setText("!BIENVENIDO!");

        lbl_texto2.setBackground(new java.awt.Color(255, 255, 255));
        lbl_texto2.setFont(new java.awt.Font("Rockwell Condensed", 1, 18)); // NOI18N
        lbl_texto2.setForeground(new java.awt.Color(255, 255, 255));
        lbl_texto2.setText("Ingrese la informacion o la seleccione una opcion para la administracion de los Servicios");

        javax.swing.GroupLayout pnl_norteLayout = new javax.swing.GroupLayout(pnl_norte);
        pnl_norte.setLayout(pnl_norteLayout);
        pnl_norteLayout.setHorizontalGroup(
            pnl_norteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_norteLayout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(pnl_norteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbl_texto2)
                    .addComponent(lbl_texto1))
                .addContainerGap(198, Short.MAX_VALUE))
        );
        pnl_norteLayout.setVerticalGroup(
            pnl_norteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_norteLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(lbl_texto1)
                .addGap(18, 18, 18)
                .addComponent(lbl_texto2)
                .addContainerGap(24, Short.MAX_VALUE))
        );

        pnl_principal.add(pnl_norte, java.awt.BorderLayout.PAGE_START);

        pnl_centro.setLayout(new java.awt.BorderLayout());

        pnl_centro_norte.setBackground(new java.awt.Color(255, 255, 255));
        pnl_centro_norte.setForeground(new java.awt.Color(255, 255, 255));

        lbl_texto3.setFont(new java.awt.Font("Rockwell Condensed", 1, 14)); // NOI18N
        lbl_texto3.setText("Nombre del Servicio*");

        lbl_texto4.setFont(new java.awt.Font("Rockwell Condensed", 1, 14)); // NOI18N
        lbl_texto4.setText("Precio*");

        lbl_texto5.setFont(new java.awt.Font("Rockwell Condensed", 1, 14)); // NOI18N
        lbl_texto5.setText(" Tiene Iva*");

        lbl_texto6.setFont(new java.awt.Font("Rockwell Condensed", 1, 14)); // NOI18N
        lbl_texto6.setText("Estado*");

        cmbbx_iva.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Si", "No" }));

        cmbbx_estado.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Activo", "Inactivo" }));

        javax.swing.GroupLayout pnl_centro_norteLayout = new javax.swing.GroupLayout(pnl_centro_norte);
        pnl_centro_norte.setLayout(pnl_centro_norteLayout);
        pnl_centro_norteLayout.setHorizontalGroup(
            pnl_centro_norteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_centro_norteLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(pnl_centro_norteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtfld_nombre_servicio, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_texto3))
                .addGap(18, 18, 18)
                .addGroup(pnl_centro_norteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbl_texto4)
                    .addComponent(txtfld_precio, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(39, 39, 39)
                .addGroup(pnl_centro_norteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cmbbx_iva, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_texto5))
                .addGap(28, 28, 28)
                .addGroup(pnl_centro_norteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cmbbx_estado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_texto6))
                .addContainerGap(299, Short.MAX_VALUE))
        );
        pnl_centro_norteLayout.setVerticalGroup(
            pnl_centro_norteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_centro_norteLayout.createSequentialGroup()
                .addGroup(pnl_centro_norteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnl_centro_norteLayout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addGroup(pnl_centro_norteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lbl_texto3)
                            .addComponent(lbl_texto4)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnl_centro_norteLayout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addGroup(pnl_centro_norteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lbl_texto5)
                            .addComponent(lbl_texto6))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnl_centro_norteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtfld_nombre_servicio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtfld_precio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbbx_iva, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbbx_estado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(28, Short.MAX_VALUE))
        );

        pnl_centro.add(pnl_centro_norte, java.awt.BorderLayout.PAGE_START);

        pnl_centro_centro.setBackground(new java.awt.Color(255, 255, 255));
        pnl_centro_centro.setForeground(new java.awt.Color(255, 255, 255));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Id", "Nombre", "Precio", "IVA", "Estado"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout pnl_centro_centroLayout = new javax.swing.GroupLayout(pnl_centro_centro);
        pnl_centro_centro.setLayout(pnl_centro_centroLayout);
        pnl_centro_centroLayout.setHorizontalGroup(
            pnl_centro_centroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnl_centro_centroLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 864, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
        );
        pnl_centro_centroLayout.setVerticalGroup(
            pnl_centro_centroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 253, Short.MAX_VALUE)
        );

        pnl_centro.add(pnl_centro_centro, java.awt.BorderLayout.CENTER);

        pnl_centro_sur.setBackground(new java.awt.Color(255, 255, 255));
        pnl_centro_sur.setForeground(new java.awt.Color(255, 255, 255));

        btn_registrar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/registrar.png"))); // NOI18N
        btn_registrar.setText("REGISTRAR");
        btn_registrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_registrarActionPerformed(evt);
            }
        });

        btn_buscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/buscar.png"))); // NOI18N
        btn_buscar.setText("BUSCAR");
        btn_buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_buscarActionPerformed(evt);
            }
        });

        btn_modificar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/modificar.png"))); // NOI18N
        btn_modificar.setText("MODIFICAR");
        btn_modificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_modificarActionPerformed(evt);
            }
        });

        btn_eliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/eliminar.png"))); // NOI18N
        btn_eliminar.setText("ELIMINAR");
        btn_eliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_eliminarActionPerformed(evt);
            }
        });

        btn_cancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/cancelar.png"))); // NOI18N
        btn_cancelar.setText("CANCELAR");
        btn_cancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cancelarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pnl_centro_surLayout = new javax.swing.GroupLayout(pnl_centro_sur);
        pnl_centro_sur.setLayout(pnl_centro_surLayout);
        pnl_centro_surLayout.setHorizontalGroup(
            pnl_centro_surLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_centro_surLayout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addComponent(btn_registrar, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34)
                .addComponent(btn_buscar, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btn_modificar, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btn_eliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 29, Short.MAX_VALUE)
                .addComponent(btn_cancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(22, 22, 22))
        );
        pnl_centro_surLayout.setVerticalGroup(
            pnl_centro_surLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_centro_surLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(pnl_centro_surLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(pnl_centro_surLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btn_cancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btn_eliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(btn_registrar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn_buscar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn_modificar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(27, Short.MAX_VALUE))
        );

        pnl_centro.add(pnl_centro_sur, java.awt.BorderLayout.PAGE_END);

        pnl_principal.add(pnl_centro, java.awt.BorderLayout.CENTER);

        getContentPane().add(pnl_principal, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_registrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_registrarActionPerformed
        String nombre = txtfld_nombre_servicio.getText();
        Double precio = Double.parseDouble(txtfld_precio.getText());
        String encargo = cmbbx_iva.getSelectedItem().toString();
        String estado = cmbbx_estado.getSelectedItem().toString(); 
        encargo = encargo.equals("Si") ? "1" : "0";
        estado = estado.equals("Activo") ? "A" : "I";
        
        
        if(controladors.registarServicio(new Servicio(1, nombre, precio, encargo.charAt(0), estado.charAt(0)))){
            JOptionPane.showMessageDialog(null, "Servicio agregado correcramente");
            
        } else{
            JOptionPane.showMessageDialog(null, "Error al agregar el servicio");
            
        }
                
        obtenerServicios();
    }//GEN-LAST:event_btn_registrarActionPerformed

    private void btn_buscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_buscarActionPerformed
        Buscar_Servicio bs=new Buscar_Servicio();
        bs.setControlador(controladors, this);
        
        bs.setVisible(true);
    }//GEN-LAST:event_btn_buscarActionPerformed

    private void btn_modificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_modificarActionPerformed
        String nombre = txtfld_nombre_servicio.getText();
        double precio = Double.parseDouble(txtfld_precio.getText());
        String encargo = cmbbx_iva.getSelectedItem().toString();
        String estado = cmbbx_estado.getSelectedItem().toString(); 
        encargo = encargo.equals("Si") ? "1" : "0";
        estado = estado.equals("Activo") ? "A" : "I";
        
        if(controladors.actualizarServicio(new Servicio(codigo, nombre, precio, encargo.charAt(0), 'a'))){
            JOptionPane.showMessageDialog(null, "Servicio modificado correcramente");
            
        } else{
            JOptionPane.showMessageDialog(null, "Error al modificar el servicio");
            
        }
        obtenerServicios();
    }//GEN-LAST:event_btn_modificarActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        codigo = Integer.parseInt(String.valueOf(jTable1.getValueAt(jTable1.getSelectedRow(),0).toString()));
        txtfld_nombre_servicio.setText(String.valueOf(jTable1.getValueAt(jTable1.getSelectedRow(),1).toString()));
        txtfld_precio.setText(String.valueOf(jTable1.getValueAt(jTable1.getSelectedRow(),2).toString()));
        
        String iva = String.valueOf(jTable1.getValueAt(jTable1.getSelectedRow(),3).toString());
        
        if("0".equals(iva)){
            cmbbx_iva.setSelectedIndex(1); 
            
        } else{
            cmbbx_iva.setSelectedIndex(0); 
        }
        
        
    }//GEN-LAST:event_jTable1MouseClicked

    private void btn_eliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_eliminarActionPerformed
        
        if(controladors.eliminarServicio(codigo)){
            JOptionPane.showMessageDialog(null, "Servicio eliminado correcramente");
            
        } else{
            JOptionPane.showMessageDialog(null, "Error al eliminar el servicio");
            
        } 
        
        obtenerServicios();
    }//GEN-LAST:event_btn_eliminarActionPerformed

    private void btn_cancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cancelarActionPerformed
        this.dispose();
    }//GEN-LAST:event_btn_cancelarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_buscar;
    private javax.swing.JButton btn_cancelar;
    private javax.swing.JButton btn_eliminar;
    private javax.swing.JButton btn_modificar;
    private javax.swing.JButton btn_registrar;
    private javax.swing.JComboBox<String> cmbbx_estado;
    private javax.swing.JComboBox<String> cmbbx_iva;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel lbl_texto1;
    private javax.swing.JLabel lbl_texto2;
    private javax.swing.JLabel lbl_texto3;
    private javax.swing.JLabel lbl_texto4;
    private javax.swing.JLabel lbl_texto5;
    private javax.swing.JLabel lbl_texto6;
    private javax.swing.JPanel pnl_centro;
    private javax.swing.JPanel pnl_centro_centro;
    private javax.swing.JPanel pnl_centro_norte;
    private javax.swing.JPanel pnl_centro_sur;
    private javax.swing.JPanel pnl_este;
    private javax.swing.JPanel pnl_norte;
    private javax.swing.JPanel pnl_principal;
    private javax.swing.JTextField txtfld_nombre_servicio;
    private javax.swing.JTextField txtfld_precio;
    // End of variables declaration//GEN-END:variables
}
