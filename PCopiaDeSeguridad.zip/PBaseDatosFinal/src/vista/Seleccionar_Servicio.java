package vista;

import controlador.ControladorServicio;
import javax.swing.table.DefaultTableModel;
import modelo.Servicio;

public class Seleccionar_Servicio extends javax.swing.JFrame {

    ControladorServicio controls; 
    Ventana_Facturar vf;
    Servicio servicio;
    
    public void setControladores(ControladorServicio controls, Ventana_Facturar vf){
        this.controls = controls;
        this.vf=vf;
    }
    
    public void setTable(Servicio servicio) {
        DefaultTableModel modeloTabla = new DefaultTableModel();
        jTable1.setModel(modeloTabla);

        modeloTabla.addColumn("Codigo");
        modeloTabla.addColumn("Nombre");
        modeloTabla.addColumn("Precio");
        modeloTabla.addColumn("IVA");

        if (servicio != null) {
            Object fila[] = new Object[4];
            fila[0] = servicio.getCodigo();
            fila[1] = servicio.getNombre();
            fila[2] = servicio.getPrecio();
            fila[3] = servicio.getIva();

            modeloTabla.addRow(fila);
        }
    }
    
    public Seleccionar_Servicio() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnl_norte = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        pnl_sur = new javax.swing.JPanel();
        btn_cancelar = new javax.swing.JButton();
        btn_aceptar = new javax.swing.JButton();
        txtfld_cantidad = new javax.swing.JTextField();
        lbl_texto3 = new javax.swing.JLabel();
        pnl_centro = new javax.swing.JPanel();
        pnl_centro_norte = new javax.swing.JPanel();
        txtfld_cedula = new javax.swing.JTextField();
        btn_buscar = new javax.swing.JButton();
        pnl_img_servicio = new javax.swing.JLabel();
        pnl_img_servicio1 = new javax.swing.JLabel();
        lbl_texto4 = new javax.swing.JLabel();
        pnl_centro_centro = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        pnl_norte.setBackground(new java.awt.Color(4, 116, 190));
        pnl_norte.setForeground(new java.awt.Color(4, 116, 190));

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Rockwell Condensed", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Seleccione una opcion de busqueda e ingrese el valor a buscar: ");

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setFont(new java.awt.Font("Rockwell Condensed", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Buscar por: ");

        javax.swing.GroupLayout pnl_norteLayout = new javax.swing.GroupLayout(pnl_norte);
        pnl_norte.setLayout(pnl_norteLayout);
        pnl_norteLayout.setHorizontalGroup(
            pnl_norteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_norteLayout.createSequentialGroup()
                .addGroup(pnl_norteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnl_norteLayout.createSequentialGroup()
                        .addGap(34, 34, 34)
                        .addComponent(jLabel1))
                    .addGroup(pnl_norteLayout.createSequentialGroup()
                        .addGap(308, 308, 308)
                        .addComponent(jLabel2)))
                .addContainerGap(40, Short.MAX_VALUE))
        );
        pnl_norteLayout.setVerticalGroup(
            pnl_norteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_norteLayout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        getContentPane().add(pnl_norte, java.awt.BorderLayout.PAGE_START);

        pnl_sur.setBackground(new java.awt.Color(255, 255, 255));
        pnl_sur.setForeground(new java.awt.Color(255, 255, 255));

        btn_cancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/cancelar.png"))); // NOI18N
        btn_cancelar.setText("CANCELAR");

        btn_aceptar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/aceptar.png"))); // NOI18N
        btn_aceptar.setText("ACEPTAR");
        btn_aceptar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_aceptarActionPerformed(evt);
            }
        });

        lbl_texto3.setFont(new java.awt.Font("Rockwell Condensed", 1, 14)); // NOI18N
        lbl_texto3.setText("Cantidad:");

        javax.swing.GroupLayout pnl_surLayout = new javax.swing.GroupLayout(pnl_sur);
        pnl_sur.setLayout(pnl_surLayout);
        pnl_surLayout.setHorizontalGroup(
            pnl_surLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_surLayout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addComponent(lbl_texto3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtfld_cantidad, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 110, Short.MAX_VALUE)
                .addComponent(btn_cancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31)
                .addComponent(btn_aceptar, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(59, 59, 59))
        );
        pnl_surLayout.setVerticalGroup(
            pnl_surLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_surLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(pnl_surLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_cancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_aceptar, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtfld_cantidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_texto3, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(42, Short.MAX_VALUE))
        );

        getContentPane().add(pnl_sur, java.awt.BorderLayout.PAGE_END);

        pnl_centro.setLayout(new java.awt.BorderLayout());

        pnl_centro_norte.setBackground(new java.awt.Color(255, 255, 255));
        pnl_centro_norte.setForeground(new java.awt.Color(255, 255, 255));
        pnl_centro_norte.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        pnl_centro_norte.add(txtfld_cedula, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 40, 250, -1));

        btn_buscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/buscar.png"))); // NOI18N
        btn_buscar.setText("BUSCAR");
        btn_buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_buscarActionPerformed(evt);
            }
        });
        pnl_centro_norte.add(btn_buscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(298, 70, 134, 48));

        pnl_img_servicio.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/servicioV.png"))); // NOI18N
        pnl_img_servicio.setText("jLabel3");
        pnl_centro_norte.add(pnl_img_servicio, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 10, 100, 100));

        pnl_img_servicio1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/servicioV.png"))); // NOI18N
        pnl_img_servicio1.setText("jLabel3");
        pnl_centro_norte.add(pnl_img_servicio1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 10, 100, 100));

        lbl_texto4.setFont(new java.awt.Font("Rockwell Condensed", 1, 14)); // NOI18N
        lbl_texto4.setText("Nombre del servicio*");
        pnl_centro_norte.add(lbl_texto4, new org.netbeans.lib.awtextra.AbsoluteConstraints(301, 12, -1, 16));

        pnl_centro.add(pnl_centro_norte, java.awt.BorderLayout.PAGE_START);

        pnl_centro_centro.setBackground(new java.awt.Color(255, 255, 255));
        pnl_centro_centro.setForeground(new java.awt.Color(255, 255, 255));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Cedula", "Nombre", "Precio", "IVA"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout pnl_centro_centroLayout = new javax.swing.GroupLayout(pnl_centro_centro);
        pnl_centro_centro.setLayout(pnl_centro_centroLayout);
        pnl_centro_centroLayout.setHorizontalGroup(
            pnl_centro_centroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 714, Short.MAX_VALUE)
        );
        pnl_centro_centroLayout.setVerticalGroup(
            pnl_centro_centroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnl_centro_centroLayout.createSequentialGroup()
                .addGap(0, 15, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 325, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pnl_centro.add(pnl_centro_centro, java.awt.BorderLayout.CENTER);

        getContentPane().add(pnl_centro, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_buscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_buscarActionPerformed
        String nombreServicio = txtfld_cedula.getText();
        servicio = controls.buscarServicio(nombreServicio);
        this.setTable(servicio);
    }//GEN-LAST:event_btn_buscarActionPerformed

    private void btn_aceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_aceptarActionPerformed
        vf.obtenerCantidad(Integer.parseInt(txtfld_cantidad.getText()));
        vf.obtenerServicio(servicio); 
    }//GEN-LAST:event_btn_aceptarActionPerformed


    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Seleccionar_Servicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Seleccionar_Servicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Seleccionar_Servicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Seleccionar_Servicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Seleccionar_Servicio().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_aceptar;
    private javax.swing.JButton btn_buscar;
    private javax.swing.JButton btn_cancelar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel lbl_texto3;
    private javax.swing.JLabel lbl_texto4;
    private javax.swing.JPanel pnl_centro;
    private javax.swing.JPanel pnl_centro_centro;
    private javax.swing.JPanel pnl_centro_norte;
    private javax.swing.JLabel pnl_img_servicio;
    private javax.swing.JLabel pnl_img_servicio1;
    private javax.swing.JPanel pnl_norte;
    private javax.swing.JPanel pnl_sur;
    private javax.swing.JTextField txtfld_cantidad;
    private javax.swing.JTextField txtfld_cedula;
    // End of variables declaration//GEN-END:variables
}
