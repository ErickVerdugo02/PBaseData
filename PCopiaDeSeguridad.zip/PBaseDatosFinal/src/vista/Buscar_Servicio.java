package vista;

import controlador.ControladorServicio;
import modelo.Servicio;


public class Buscar_Servicio extends javax.swing.JFrame {

    ControladorServicio controls;
    Ventana_Servicios vs;
    
    public Buscar_Servicio() {
        initComponents();
        this.setLocationRelativeTo(null);
    }

    public void setControlador(ControladorServicio controls, Ventana_Servicios vs){
        this.controls=controls;
        this.vs=vs;
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnl_sur = new javax.swing.JPanel();
        btn_cancelar = new javax.swing.JButton();
        btn_buscar = new javax.swing.JButton();
        pnl_norte = new javax.swing.JPanel();
        lbl_texto1 = new javax.swing.JLabel();
        lbl_texto2 = new javax.swing.JLabel();
        pnl_centro = new javax.swing.JPanel();
        txtfld_cedula = new javax.swing.JTextField();
        lbl_texto3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);

        pnl_sur.setBackground(new java.awt.Color(255, 255, 255));
        pnl_sur.setForeground(new java.awt.Color(255, 255, 255));

        btn_cancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/cancelar.png"))); // NOI18N
        btn_cancelar.setText("CANCELAR");

        btn_buscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/buscar.png"))); // NOI18N
        btn_buscar.setText("BUSCAR");
        btn_buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_buscarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pnl_surLayout = new javax.swing.GroupLayout(pnl_sur);
        pnl_sur.setLayout(pnl_surLayout);
        pnl_surLayout.setHorizontalGroup(
            pnl_surLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_surLayout.createSequentialGroup()
                .addGap(175, 175, 175)
                .addComponent(btn_cancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35)
                .addComponent(btn_buscar, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(165, Short.MAX_VALUE))
        );
        pnl_surLayout.setVerticalGroup(
            pnl_surLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_surLayout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addGroup(pnl_surLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_cancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_buscar, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(28, Short.MAX_VALUE))
        );

        getContentPane().add(pnl_sur, java.awt.BorderLayout.PAGE_END);

        pnl_norte.setBackground(new java.awt.Color(4, 116, 190));
        pnl_norte.setForeground(new java.awt.Color(4, 116, 190));

        lbl_texto1.setBackground(new java.awt.Color(255, 255, 255));
        lbl_texto1.setFont(new java.awt.Font("Rockwell Condensed", 1, 24)); // NOI18N
        lbl_texto1.setForeground(new java.awt.Color(255, 255, 255));
        lbl_texto1.setText("Seleccione una opcion de busqueda e ingrese el valor a buscar: ");

        lbl_texto2.setBackground(new java.awt.Color(255, 255, 255));
        lbl_texto2.setFont(new java.awt.Font("Rockwell Condensed", 1, 18)); // NOI18N
        lbl_texto2.setForeground(new java.awt.Color(255, 255, 255));
        lbl_texto2.setText("Buscar por: ");

        javax.swing.GroupLayout pnl_norteLayout = new javax.swing.GroupLayout(pnl_norte);
        pnl_norte.setLayout(pnl_norteLayout);
        pnl_norteLayout.setHorizontalGroup(
            pnl_norteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_norteLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(pnl_norteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnl_norteLayout.createSequentialGroup()
                        .addComponent(lbl_texto2, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(275, 275, 275))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnl_norteLayout.createSequentialGroup()
                        .addComponent(lbl_texto1)
                        .addContainerGap())))
        );
        pnl_norteLayout.setVerticalGroup(
            pnl_norteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_norteLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(lbl_texto1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lbl_texto2, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(pnl_norte, java.awt.BorderLayout.PAGE_START);

        pnl_centro.setBackground(new java.awt.Color(255, 255, 255));
        pnl_centro.setForeground(new java.awt.Color(255, 255, 255));

        txtfld_cedula.setFont(new java.awt.Font("Rockwell Condensed", 1, 14)); // NOI18N

        lbl_texto3.setFont(new java.awt.Font("Rockwell Condensed", 1, 14)); // NOI18N
        lbl_texto3.setText("Ingrese el nombre del servicio a buscar:");

        javax.swing.GroupLayout pnl_centroLayout = new javax.swing.GroupLayout(pnl_centro);
        pnl_centro.setLayout(pnl_centroLayout);
        pnl_centroLayout.setHorizontalGroup(
            pnl_centroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_centroLayout.createSequentialGroup()
                .addGap(198, 198, 198)
                .addGroup(pnl_centroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbl_texto3)
                    .addComponent(txtfld_cedula, javax.swing.GroupLayout.PREFERRED_SIZE, 238, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(218, Short.MAX_VALUE))
        );
        pnl_centroLayout.setVerticalGroup(
            pnl_centroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_centroLayout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(lbl_texto3, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtfld_cedula, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(138, Short.MAX_VALUE))
        );

        getContentPane().add(pnl_centro, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_buscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_buscarActionPerformed
        String nombre = txtfld_cedula.getText();
        Servicio servicio = controls.buscarServicio(nombre);
        vs.obtenerServicio(servicio);
    }//GEN-LAST:event_btn_buscarActionPerformed


    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Buscar_Servicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Buscar_Servicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Buscar_Servicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Buscar_Servicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Buscar_Servicio().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_buscar;
    private javax.swing.JButton btn_cancelar;
    private javax.swing.JLabel lbl_texto1;
    private javax.swing.JLabel lbl_texto2;
    private javax.swing.JLabel lbl_texto3;
    private javax.swing.JPanel pnl_centro;
    private javax.swing.JPanel pnl_norte;
    private javax.swing.JPanel pnl_sur;
    private javax.swing.JTextField txtfld_cedula;
    // End of variables declaration//GEN-END:variables
}
