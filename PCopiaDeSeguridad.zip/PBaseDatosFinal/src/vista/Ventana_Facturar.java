package vista;

import controlador.*;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.table.DefaultTableModel;
import modelo.CabeceraFactura;
import modelo.DetalleFactura;
import modelo.Persona;
import modelo.Servicio;
import modelo.Usuario;


public class Ventana_Facturar extends javax.swing.JInternalFrame {

    Usuario usuarioFactura;
    Persona cliente;
    
    private ControladorPersonal controlp;
    private ControladorServicio controls;
    private ControladorCabeceraFactura controlcf;
    
    private ControladorCabeceraFactura controlcf2 = new ControladorCabeceraFactura();
    
    String cedulaCiente, nombreCiente, correoCliente;
    int cantidad;
    int fila = 0;
    double iva = 0, subtotal = 0;
    double ivaEliminar = 0;
    double subtotalEliminar = 0;
            
    DefaultTableModel modeloTabla = new DefaultTableModel();

    DateFormat dateFormat = new SimpleDateFormat("EEE, d MMM yyyy, HH:mm:ss");
    String date = dateFormat.format(new Date());
    
    public void obtenerCantidad(int cantidad){
        this.cantidad = cantidad;
    }
    
    public void obtenerCliente(Persona cliente){
        this.cliente = cliente;
        
        txtfld_cedula.setText(this.cliente.getCedula());
        txtfld_nombre.setText(this.cliente.getNombres() + " " + cliente.getApellidos());
        txtfld_correo.setText(this.cliente.getCorreo());
    } 
    
    
    public void setControladores(ControladorPersonal controlp, ControladorServicio controls, ControladorCabeceraFactura controlcf){
        this.controlp=controlp;
        this.controls=controls;
        this.controlcf = controlcf;
    }
    
    public void obtenerServicio(Servicio servicio){
        this.setTable(servicio);
        calcularTotales();
        
    }
    
    public void calcularTotales(){
        iva = iva + Double.parseDouble(jTable1.getValueAt(fila, 4).toString());
        subtotal = subtotal + Double.parseDouble(jTable1.getValueAt(fila, 5).toString());
        
        txtfld_subtotal.setText(String.valueOf(subtotal));
        txtfld_iva.setText(String.valueOf(iva)); 
        
        txtfld_total.setText(String.valueOf(Double.parseDouble(txtfld_subtotal.getText()) + Double.parseDouble(txtfld_iva.getText()))); 
        fila ++;
        
        
    }
    
    public void calcularTotalesEliminar(){
        ivaEliminar = 0;
        subtotalEliminar = 0;
        
        for(int i=0; i<modeloTabla.getRowCount(); i++){
            ivaEliminar = ivaEliminar + Double.parseDouble(jTable1.getValueAt(i, 4).toString());
            subtotalEliminar = subtotalEliminar + Double.parseDouble(jTable1.getValueAt(i, 5).toString());
        }
        
        txtfld_subtotal.setText(String.valueOf(subtotalEliminar));
        txtfld_iva.setText(String.valueOf(ivaEliminar)); 
        
        txtfld_total.setText(String.valueOf(Double.parseDouble(txtfld_subtotal.getText()) + Double.parseDouble(txtfld_iva.getText())));
        
        iva = ivaEliminar;
        subtotal = subtotalEliminar;
        
        fila = modeloTabla.getRowCount();
    }
    
    public void setTable(Servicio servicio) {


        if (servicio != null) {
            Object fila[] = new Object[7];
            fila[0] = servicio.getCodigo();
            fila[1] = servicio.getNombre();
            fila[2] = servicio.getPrecio();
            fila[3] = cantidad; 
            fila[4] = ((servicio.getPrecio() * cantidad) * 0.12);
            fila[5] = (servicio.getPrecio() * cantidad);
            fila[6] = ((servicio.getPrecio() * cantidad) * 0.12) + (servicio.getPrecio() * cantidad); 

            modeloTabla.addRow(fila);
        }
    }
    
    public void obtenerUsuario(Usuario usuarioFactura){
        this.usuarioFactura = usuarioFactura;
        txtfld_factura.setText(this.usuarioFactura.getUsername());
    }
        
    
    public Ventana_Facturar() {
        initComponents();
        //int numereroFactura = controlcf.numeroFactura();
        txtfld_numero_factura.setText(String.valueOf(controlcf2.numeroFactura() + 1)); 
        txtfld_fecha.setText(date); 
        
        jTable1.setModel(modeloTabla);

        modeloTabla.addColumn("Codigo");
        modeloTabla.addColumn("Servicio");
        modeloTabla.addColumn("Precio");
        modeloTabla.addColumn("Cantidad");
        modeloTabla.addColumn("Iva");
        modeloTabla.addColumn("Subtotal");
        modeloTabla.addColumn("Total");
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lbl_principal = new javax.swing.JPanel();
        lbl_norte = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        lbl_factura = new javax.swing.JLabel();
        lbl_factura1 = new javax.swing.JLabel();
        lbl_centro = new javax.swing.JPanel();
        btn_seleccionar_cliente = new javax.swing.JButton();
        lbl_texto4 = new javax.swing.JLabel();
        lbl_texto5 = new javax.swing.JLabel();
        txtfld_factura = new javax.swing.JTextField();
        lbl_texto6 = new javax.swing.JLabel();
        txtfld_numero_factura = new javax.swing.JTextField();
        lbl_texto7 = new javax.swing.JLabel();
        txtfld_cedula = new javax.swing.JTextField();
        lbl_texto8 = new javax.swing.JLabel();
        txtfld_nombre = new javax.swing.JTextField();
        lbl_texto9 = new javax.swing.JLabel();
        txtfld_correo = new javax.swing.JTextField();
        btn_eliminar_servicio = new javax.swing.JButton();
        btn_agregar_servicio = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        btn_cancelar_factura = new javax.swing.JButton();
        btn_confirmar_factura = new javax.swing.JButton();
        lbl_texto10 = new javax.swing.JLabel();
        txtfld_iva = new javax.swing.JTextField();
        lbl_texto11 = new javax.swing.JLabel();
        txtfld_subtotal = new javax.swing.JTextField();
        lbl_texto12 = new javax.swing.JLabel();
        txtfld_total = new javax.swing.JTextField();
        txtfld_fecha = new javax.swing.JTextField();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);

        lbl_principal.setLayout(new java.awt.BorderLayout());

        lbl_norte.setBackground(new java.awt.Color(4, 116, 190));
        lbl_norte.setForeground(new java.awt.Color(4, 116, 190));
        lbl_norte.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/minilogo.png"))); // NOI18N
        jLabel1.setText("jLabel1");
        lbl_norte.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 0, 135, 100));

        lbl_factura.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/servicioV.png"))); // NOI18N
        lbl_norte.add(lbl_factura, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 0, 130, -1));

        lbl_factura1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/servicioV.png"))); // NOI18N
        lbl_norte.add(lbl_factura1, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 0, 130, -1));

        lbl_principal.add(lbl_norte, java.awt.BorderLayout.PAGE_START);

        lbl_centro.setBackground(new java.awt.Color(255, 255, 255));
        lbl_centro.setForeground(new java.awt.Color(255, 255, 255));

        btn_seleccionar_cliente.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/cliente.png"))); // NOI18N
        btn_seleccionar_cliente.setText("SELECCIONE AL CLIENTE");
        btn_seleccionar_cliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_seleccionar_clienteActionPerformed(evt);
            }
        });

        lbl_texto4.setFont(new java.awt.Font("Rockwell Condensed", 1, 14)); // NOI18N
        lbl_texto4.setText("Fecha:");

        lbl_texto5.setFont(new java.awt.Font("Rockwell Condensed", 1, 14)); // NOI18N
        lbl_texto5.setText("Factura realizada por:");

        txtfld_factura.setEditable(false);

        lbl_texto6.setFont(new java.awt.Font("Rockwell Condensed", 1, 14)); // NOI18N
        lbl_texto6.setText("#Factura");

        txtfld_numero_factura.setEditable(false);

        lbl_texto7.setFont(new java.awt.Font("Rockwell Condensed", 1, 14)); // NOI18N
        lbl_texto7.setText("Cedula del Cliente: ");

        lbl_texto8.setFont(new java.awt.Font("Rockwell Condensed", 1, 14)); // NOI18N
        lbl_texto8.setText("Nombre del cliente:");

        lbl_texto9.setFont(new java.awt.Font("Rockwell Condensed", 1, 14)); // NOI18N
        lbl_texto9.setText("Correo del Cliente: ");

        btn_eliminar_servicio.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/eliminar.png"))); // NOI18N
        btn_eliminar_servicio.setText("ELIMINAR SERVICIO");
        btn_eliminar_servicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_eliminar_servicioActionPerformed(evt);
            }
        });

        btn_agregar_servicio.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/agregarservicio.png"))); // NOI18N
        btn_agregar_servicio.setText("AGREGAR EL SERVICIO");
        btn_agregar_servicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_agregar_servicioActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Id", "Servicio", "Precio", "Cantidad", "Iva", "Subtotal", "Total"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        btn_cancelar_factura.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/cancelarfactura.png"))); // NOI18N
        btn_cancelar_factura.setText("CANCELAR FACTURA");
        btn_cancelar_factura.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cancelar_facturaActionPerformed(evt);
            }
        });

        btn_confirmar_factura.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/confirmarfactura.png"))); // NOI18N
        btn_confirmar_factura.setText("CONFIRMAR FACTURA");
        btn_confirmar_factura.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_confirmar_facturaActionPerformed(evt);
            }
        });

        lbl_texto10.setFont(new java.awt.Font("Rockwell Condensed", 1, 14)); // NOI18N
        lbl_texto10.setText("IVA:");

        lbl_texto11.setFont(new java.awt.Font("Rockwell Condensed", 1, 14)); // NOI18N
        lbl_texto11.setText("Subtotal: ");

        lbl_texto12.setFont(new java.awt.Font("Rockwell Condensed", 1, 14)); // NOI18N
        lbl_texto12.setText("Total:");

        txtfld_fecha.setEditable(false);

        javax.swing.GroupLayout lbl_centroLayout = new javax.swing.GroupLayout(lbl_centro);
        lbl_centro.setLayout(lbl_centroLayout);
        lbl_centroLayout.setHorizontalGroup(
            lbl_centroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(lbl_centroLayout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(lbl_centroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, lbl_centroLayout.createSequentialGroup()
                        .addGroup(lbl_centroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(lbl_centroLayout.createSequentialGroup()
                                .addGroup(lbl_centroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(lbl_centroLayout.createSequentialGroup()
                                        .addComponent(lbl_texto7)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtfld_cedula, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(lbl_centroLayout.createSequentialGroup()
                                        .addComponent(btn_seleccionar_cliente)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(lbl_texto4)))
                                .addGroup(lbl_centroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(lbl_centroLayout.createSequentialGroup()
                                        .addGap(57, 57, 57)
                                        .addComponent(lbl_texto8)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtfld_nombre))
                                    .addGroup(lbl_centroLayout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtfld_fecha, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(26, 26, 26)
                                        .addComponent(lbl_texto5)))
                                .addGroup(lbl_centroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(lbl_centroLayout.createSequentialGroup()
                                        .addGap(18, 18, 18)
                                        .addComponent(txtfld_factura, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(lbl_texto6)
                                        .addGap(18, 18, 18)
                                        .addComponent(txtfld_numero_factura, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(lbl_centroLayout.createSequentialGroup()
                                        .addGap(25, 25, 25)
                                        .addComponent(lbl_texto9)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtfld_correo, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 0, Short.MAX_VALUE))))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(lbl_centroLayout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(lbl_texto11)
                                .addGap(18, 18, 18)
                                .addComponent(txtfld_subtotal, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(lbl_texto10)
                                .addGap(18, 18, 18)
                                .addComponent(txtfld_iva, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(lbl_texto12)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtfld_total, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(lbl_centroLayout.createSequentialGroup()
                                .addGap(16, 16, 16)
                                .addComponent(btn_eliminar_servicio)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btn_agregar_servicio)
                                .addGap(35, 35, 35)))
                        .addGap(25, 25, 25))
                    .addGroup(lbl_centroLayout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(btn_cancelar_factura)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btn_confirmar_factura)
                        .addGap(44, 44, 44))))
        );
        lbl_centroLayout.setVerticalGroup(
            lbl_centroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(lbl_centroLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(lbl_centroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btn_seleccionar_cliente)
                    .addGroup(lbl_centroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lbl_texto5)
                        .addComponent(txtfld_factura, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(lbl_texto6)
                        .addComponent(txtfld_numero_factura, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(lbl_centroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lbl_texto4)
                        .addComponent(txtfld_fecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(29, 29, 29)
                .addGroup(lbl_centroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_texto7)
                    .addComponent(txtfld_cedula, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_texto8)
                    .addComponent(txtfld_nombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_texto9)
                    .addComponent(txtfld_correo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(lbl_centroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btn_eliminar_servicio, javax.swing.GroupLayout.DEFAULT_SIZE, 40, Short.MAX_VALUE)
                    .addComponent(btn_agregar_servicio, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 317, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(lbl_centroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_texto12)
                    .addComponent(txtfld_total, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtfld_iva, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_texto10)
                    .addComponent(txtfld_subtotal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_texto11))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(lbl_centroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btn_cancelar_factura, javax.swing.GroupLayout.DEFAULT_SIZE, 40, Short.MAX_VALUE)
                    .addComponent(btn_confirmar_factura))
                .addGap(27, 27, 27))
        );

        lbl_principal.add(lbl_centro, java.awt.BorderLayout.CENTER);

        getContentPane().add(lbl_principal, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_seleccionar_clienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_seleccionar_clienteActionPerformed
        Seleccionar_Cliente sc=new Seleccionar_Cliente();
        sc.setControlador(controlp, this);
        sc.setVisible(true);
    }//GEN-LAST:event_btn_seleccionar_clienteActionPerformed

    private void btn_agregar_servicioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_agregar_servicioActionPerformed
        Seleccionar_Servicio ss=new Seleccionar_Servicio();
        ss.setControladores(controls, this);
        ss.setVisible(true);
    }//GEN-LAST:event_btn_agregar_servicioActionPerformed

    private void btn_eliminar_servicioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_eliminar_servicioActionPerformed
        modeloTabla.removeRow(jTable1.getSelectedRow());
        calcularTotalesEliminar();
    }//GEN-LAST:event_btn_eliminar_servicioActionPerformed

    private void btn_confirmar_facturaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_confirmar_facturaActionPerformed

        Date date = new Date();

        Timestamp timestamp = new Timestamp(date.getTime());
        
        SimpleDateFormat formatoFecha = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String fechaFormateada = formatoFecha.format(timestamp);
        
        
        double subtotal = Double.parseDouble(txtfld_subtotal.getText()); 
        double iva = Double.parseDouble(txtfld_iva.getText()); 
        double total = Double.parseDouble(txtfld_total.getText()); 
        int codigoCliente = this.cliente.getCodigo();
        int codigoUsuario = this.usuarioFactura.getCodigo();
        String estadoFactura = "EMITIDO";
        
        controlcf.registrarCabeceraFactura(new CabeceraFactura(timestamp, subtotal, iva, total, codigoCliente, codigoUsuario, estadoFactura));
        
        
        this.registrarDetalle();
    }//GEN-LAST:event_btn_confirmar_facturaActionPerformed

    private void btn_cancelar_facturaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cancelar_facturaActionPerformed
        
    }//GEN-LAST:event_btn_cancelar_facturaActionPerformed
    
    public void registrarDetalle(){
        int codigoFacura = Integer.parseInt(txtfld_numero_factura.getText()), cantidad = 0, servicioCodigo = 0;
        double precio = 0, subtotalDetalle = 0, ivaDetalle = 0, totalDetalle = 0;
        
        ControladorDetalleFactura controldf = new ControladorDetalleFactura();
        
        for(int i=0; i<modeloTabla.getRowCount(); i++){
            cantidad = Integer.parseInt(jTable1.getValueAt(i, 3).toString());
            precio = Double.parseDouble(jTable1.getValueAt(i, 2).toString());
            subtotalDetalle = Double.parseDouble(jTable1.getValueAt(i, 4).toString());
            ivaDetalle = Double.parseDouble(jTable1.getValueAt(i, 5).toString());
            totalDetalle = Double.parseDouble(jTable1.getValueAt(i, 6).toString());
            servicioCodigo = Integer.parseInt(jTable1.getValueAt(i, 0).toString());
            //System.out.println(cantidad + " - " + precio + " - "+ subtotalDetalle + " - "+ ivaDetalle + " - "+ totalDetalle + " - "+ servicioCodigo);
            
            controldf.registrarCabeceraFactura(new DetalleFactura(codigoFacura, cantidad, servicioCodigo, precio, subtotalDetalle, ivaDetalle, totalDetalle));
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_agregar_servicio;
    private javax.swing.JButton btn_cancelar_factura;
    private javax.swing.JButton btn_confirmar_factura;
    private javax.swing.JButton btn_eliminar_servicio;
    private javax.swing.JButton btn_seleccionar_cliente;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JPanel lbl_centro;
    private javax.swing.JLabel lbl_factura;
    private javax.swing.JLabel lbl_factura1;
    private javax.swing.JPanel lbl_norte;
    private javax.swing.JPanel lbl_principal;
    private javax.swing.JLabel lbl_texto10;
    private javax.swing.JLabel lbl_texto11;
    private javax.swing.JLabel lbl_texto12;
    private javax.swing.JLabel lbl_texto4;
    private javax.swing.JLabel lbl_texto5;
    private javax.swing.JLabel lbl_texto6;
    private javax.swing.JLabel lbl_texto7;
    private javax.swing.JLabel lbl_texto8;
    private javax.swing.JLabel lbl_texto9;
    private javax.swing.JTextField txtfld_cedula;
    private javax.swing.JTextField txtfld_correo;
    private javax.swing.JTextField txtfld_factura;
    public javax.swing.JTextField txtfld_fecha;
    private javax.swing.JTextField txtfld_iva;
    private javax.swing.JTextField txtfld_nombre;
    private javax.swing.JTextField txtfld_numero_factura;
    private javax.swing.JTextField txtfld_subtotal;
    private javax.swing.JTextField txtfld_total;
    // End of variables declaration//GEN-END:variables
}
