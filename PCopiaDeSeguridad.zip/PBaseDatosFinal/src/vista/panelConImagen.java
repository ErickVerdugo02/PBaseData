/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
/**
 *
 * @author Usuario
 */
public class panelConImagen extends JPanel {
    private BufferedImage image;

    public panelConImagen() {
        try {
            // Cargar la imagen desde un archivo
            image = ImageIO.read(new File("src\\iconos\\usuario3.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    /*public void setRuta(String root)
    {
        try {
            // Cargar la imagen desde un archivo
            image = ImageIO.read(new File(root));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }*/

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        
        // Dibujar la imagen en el fondo del panel
        if (image != null) {
            g.drawImage(image, 0, 0, getWidth(), getHeight(), this);
        }
    }

}
