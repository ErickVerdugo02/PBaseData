package vista;

import java.awt.BorderLayout;
import controlador.*;
import modelo.Usuario;


public class Buscar_Usuario extends javax.swing.JFrame {

    ControladorUsuario controlu;
    
    Buscar_Cita_Cedula bcc=new Buscar_Cita_Cedula();
    
    private Ventana_Usuarios vu;
    
    
    
    public void setControlador(ControladorUsuario controlu,Ventana_Usuarios vu){
        this.controlu=controlu;
        this.vu=vu;
    }
    
    public Buscar_Usuario() {
        initComponents();
        this.setLocationRelativeTo(null);
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnl_sur = new javax.swing.JPanel();
        btn_cancelar = new javax.swing.JButton();
        btn_buscar = new javax.swing.JButton();
        pnl_norte = new javax.swing.JPanel();
        lbl_texto1 = new javax.swing.JLabel();
        lbl_texto2 = new javax.swing.JLabel();
        pnl_centro = new javax.swing.JPanel();
        rdbtn_cedula = new javax.swing.JRadioButton();
        rdbtn_nombre = new javax.swing.JRadioButton();
        pnl_centro_centro = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);

        pnl_sur.setBackground(new java.awt.Color(255, 255, 255));
        pnl_sur.setForeground(new java.awt.Color(255, 255, 255));

        btn_cancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/cancelar.png"))); // NOI18N
        btn_cancelar.setText("CANCELAR");

        btn_buscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/buscar.png"))); // NOI18N
        btn_buscar.setText("BUSCAR");
        btn_buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_buscarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pnl_surLayout = new javax.swing.GroupLayout(pnl_sur);
        pnl_sur.setLayout(pnl_surLayout);
        pnl_surLayout.setHorizontalGroup(
            pnl_surLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_surLayout.createSequentialGroup()
                .addGap(209, 209, 209)
                .addComponent(btn_cancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(74, 74, 74)
                .addComponent(btn_buscar, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(171, Short.MAX_VALUE))
        );
        pnl_surLayout.setVerticalGroup(
            pnl_surLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_surLayout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addGroup(pnl_surLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_cancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_buscar, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(28, Short.MAX_VALUE))
        );

        getContentPane().add(pnl_sur, java.awt.BorderLayout.PAGE_END);

        pnl_norte.setBackground(new java.awt.Color(4, 116, 190));
        pnl_norte.setForeground(new java.awt.Color(4, 116, 190));

        lbl_texto1.setBackground(new java.awt.Color(255, 255, 255));
        lbl_texto1.setFont(new java.awt.Font("Rockwell Condensed", 1, 24)); // NOI18N
        lbl_texto1.setForeground(new java.awt.Color(255, 255, 255));
        lbl_texto1.setText("Seleccione una opcion de busqueda e ingrese el valor a buscar: ");

        lbl_texto2.setBackground(new java.awt.Color(255, 255, 255));
        lbl_texto2.setFont(new java.awt.Font("Rockwell Condensed", 1, 18)); // NOI18N
        lbl_texto2.setForeground(new java.awt.Color(255, 255, 255));
        lbl_texto2.setText("Buscar por: ");

        javax.swing.GroupLayout pnl_norteLayout = new javax.swing.GroupLayout(pnl_norte);
        pnl_norte.setLayout(pnl_norteLayout);
        pnl_norteLayout.setHorizontalGroup(
            pnl_norteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_norteLayout.createSequentialGroup()
                .addContainerGap(47, Short.MAX_VALUE)
                .addGroup(pnl_norteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnl_norteLayout.createSequentialGroup()
                        .addComponent(lbl_texto1)
                        .addGap(42, 42, 42))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnl_norteLayout.createSequentialGroup()
                        .addComponent(lbl_texto2, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(319, 319, 319))))
        );
        pnl_norteLayout.setVerticalGroup(
            pnl_norteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_norteLayout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(lbl_texto1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lbl_texto2, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(pnl_norte, java.awt.BorderLayout.PAGE_START);

        pnl_centro.setBackground(new java.awt.Color(255, 255, 255));
        pnl_centro.setForeground(new java.awt.Color(255, 255, 255));

        rdbtn_cedula.setFont(new java.awt.Font("Rockwell Condensed", 1, 14)); // NOI18N
        rdbtn_cedula.setText("Cedula");
        rdbtn_cedula.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdbtn_cedulaActionPerformed(evt);
            }
        });

        rdbtn_nombre.setFont(new java.awt.Font("Rockwell Condensed", 1, 14)); // NOI18N
        rdbtn_nombre.setText("Nombre del usuario");
        rdbtn_nombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdbtn_nombreActionPerformed(evt);
            }
        });

        pnl_centro_centro.setBackground(new java.awt.Color(255, 255, 255));
        pnl_centro_centro.setForeground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout pnl_centro_centroLayout = new javax.swing.GroupLayout(pnl_centro_centro);
        pnl_centro_centro.setLayout(pnl_centro_centroLayout);
        pnl_centro_centroLayout.setHorizontalGroup(
            pnl_centro_centroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 729, Short.MAX_VALUE)
        );
        pnl_centro_centroLayout.setVerticalGroup(
            pnl_centro_centroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 229, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout pnl_centroLayout = new javax.swing.GroupLayout(pnl_centro);
        pnl_centro.setLayout(pnl_centroLayout);
        pnl_centroLayout.setHorizontalGroup(
            pnl_centroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_centroLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(rdbtn_cedula, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(50, 50, 50)
                .addComponent(rdbtn_nombre)
                .addGap(209, 209, 209))
            .addGroup(pnl_centroLayout.createSequentialGroup()
                .addComponent(pnl_centro_centro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        pnl_centroLayout.setVerticalGroup(
            pnl_centroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_centroLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(pnl_centroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rdbtn_cedula)
                    .addComponent(rdbtn_nombre))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pnl_centro_centro, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(pnl_centro, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void rdbtn_cedulaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdbtn_cedulaActionPerformed
        if(rdbtn_cedula.isSelected()==true)
        {
            rdbtn_nombre.setSelected(false);
        }
        this.agregarVentanaCita(true);
    }//GEN-LAST:event_rdbtn_cedulaActionPerformed

    private void rdbtn_nombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdbtn_nombreActionPerformed
        if(rdbtn_nombre.isSelected()==true)
        {
            rdbtn_cedula.setSelected(false);
        }
        this.agregarVentanaCita(false);
    }//GEN-LAST:event_rdbtn_nombreActionPerformed

    private void btn_buscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_buscarActionPerformed
        String cedula = bcc.txtfld_cedula.getText();
        
        vu.obtenerUsuario(controlu.buscarUsuario(cedula));
    }//GEN-LAST:event_btn_buscarActionPerformed
    
    public void agregarVentanaCita(boolean llave)
    {
        if(llave==true)
        {
            
            bcc.setSize(731,250);
            bcc.setLocation(0,0);
            pnl_centro_centro.removeAll();
            pnl_centro_centro.add(bcc,BorderLayout.CENTER);
            pnl_centro_centro.revalidate();
            pnl_centro_centro.repaint();
        }else{
            Buscar_Cita_Nombre bcn=new  Buscar_Cita_Nombre();
            bcn.setSize(731,250);
            bcn.setLocation(0,0);
            pnl_centro_centro.removeAll();
            pnl_centro_centro.add(bcn,BorderLayout.CENTER);
            pnl_centro_centro.revalidate();
            pnl_centro_centro.repaint();
        }
    }
    

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Buscar_Usuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Buscar_Usuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Buscar_Usuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Buscar_Usuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Buscar_Usuario().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_buscar;
    private javax.swing.JButton btn_cancelar;
    private javax.swing.JLabel lbl_texto1;
    private javax.swing.JLabel lbl_texto2;
    private javax.swing.JPanel pnl_centro;
    private javax.swing.JPanel pnl_centro_centro;
    private javax.swing.JPanel pnl_norte;
    private javax.swing.JPanel pnl_sur;
    private javax.swing.JRadioButton rdbtn_cedula;
    private javax.swing.JRadioButton rdbtn_nombre;
    // End of variables declaration//GEN-END:variables
}
