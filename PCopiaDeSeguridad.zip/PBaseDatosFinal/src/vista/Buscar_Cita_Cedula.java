package vista;


public class Buscar_Cita_Cedula extends javax.swing.JPanel {


    public Buscar_Cita_Cedula() {
        initComponents();
        this.setSize(731,250);
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelRound1 = new vista.PanelRound();
        txtfld_cedula = new javax.swing.JTextField();
        lbl_texto1 = new javax.swing.JLabel();
        lbl_cedula = new javax.swing.JLabel();
        lbl_cedula1 = new javax.swing.JLabel();

        setBackground(new java.awt.Color(255, 255, 255));
        setForeground(new java.awt.Color(255, 255, 255));
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        panelRound1.setBackground(new java.awt.Color(4, 116, 190));
        panelRound1.setForeground(new java.awt.Color(4, 116, 190));
        panelRound1.setRoundBottomLeft(50);
        panelRound1.setRoundBottomRight(50);
        panelRound1.setRoundTopLeft(50);
        panelRound1.setRoundTopRight(50);
        panelRound1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtfld_cedula.setFont(new java.awt.Font("Rockwell Condensed", 1, 14)); // NOI18N
        panelRound1.add(txtfld_cedula, new org.netbeans.lib.awtextra.AbsoluteConstraints(258, 74, 178, -1));

        lbl_texto1.setBackground(new java.awt.Color(255, 255, 255));
        lbl_texto1.setFont(new java.awt.Font("Rockwell Condensed", 1, 18)); // NOI18N
        lbl_texto1.setForeground(new java.awt.Color(255, 255, 255));
        lbl_texto1.setText("Ingrese el numero de cedula*");
        panelRound1.add(lbl_texto1, new org.netbeans.lib.awtextra.AbsoluteConstraints(239, 34, 232, -1));

        lbl_cedula.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/cedula_1.png"))); // NOI18N
        panelRound1.add(lbl_cedula, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 50, 110, 90));

        lbl_cedula1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/cedula_1.png"))); // NOI18N
        panelRound1.add(lbl_cedula1, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 50, 110, 90));

        add(panelRound1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 690, 220));
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel lbl_cedula;
    private javax.swing.JLabel lbl_cedula1;
    private javax.swing.JLabel lbl_texto1;
    private vista.PanelRound panelRound1;
    public javax.swing.JTextField txtfld_cedula;
    // End of variables declaration//GEN-END:variables
}
