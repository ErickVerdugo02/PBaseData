/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author Lenovo
 */
public class Registro 
{
    private Cita cita;
    private Persona persona;
    private Mascota mascota;

    public Registro(Cita cita, Persona persona, Mascota mascota) {
        this.cita = cita;
        this.persona = persona;
        this.mascota = mascota;
    }

    public Cita getCita() {
        return cita;
    }

    public void setCita(Cita cita) {
        this.cita = cita;
    }

    public Persona getPersona() {
        return persona;
    }

    public void setPersona(Persona persona) {
        this.persona = persona;
    }

    public Mascota getMascota() {
        return mascota;
    }

    public void setMascota(Mascota mascota) {
        this.mascota = mascota;
    }

    @Override
    public String toString() {
        return "Registro{" + "cita=" + cita + ", persona=" + persona + ", mascota=" + mascota + '}';
    }
    
    
}
