package modelo;


public class Usuario 
{
    //Atributos del usuario
    private int codigo;
    private int codigo_per;
    private String username;
    private String contrasenia;
    private char permiso;
    private char estado; 
    //Constructor del usuario
    public Usuario(int codigo_per, String username, String contrasenia, char permiso, char estado) {
        this.codigo_per = codigo_per;
        this.username = username;
        this.contrasenia = contrasenia;
        this.permiso = permiso;
        this.estado = estado;
    }
        
    public Usuario(int codigo, int codigo_per, String username, String contrasenia, char permiso, char estado) {
        this.codigo=codigo;
        this.codigo_per = codigo_per;
        this.username = username;
        this.contrasenia = contrasenia;
        this.permiso = permiso;
        this.estado = estado;
    }
    
    //Getters y Setters del usuario
    public void setCodigo(int codigo)
    {
        this.codigo=codigo;
    }
    public int getCodigo()
    {
        return codigo;
    }
    public void setCodigo_per(int codigo_per)
    {
        this.codigo_per=codigo_per;
    }
    public int getCodigo_per()
    {
        return codigo_per;
    }
    public void setUsername(String username)
    {
        this.username=username;
    }
    public String getUsername()
    {
        return username;
    }
    public void setContrasenia(String contrasenia)
    {
        this.contrasenia=contrasenia;
    }
    public String getContrasenia()
    {
        return contrasenia;
    }
    public void setPermiso(char permiso)
    {
        this.permiso=permiso;
    }
    public char getPermiso()
    {
        return permiso;
    }
    public void setEstado(char estado)
    {
        this.estado=estado;
    }
    public char getEstado()
    {
        return estado;
    }
    //toString del usuario
    @Override
    public String toString() {
        return "Usuario{" + "codigo=" + codigo + ", codigo_per=" + codigo_per +
                ", username=" + username + ", contrasenia=" + contrasenia +
                ", permiso=" + permiso + ", estado=" + estado + '}';
    }
}
