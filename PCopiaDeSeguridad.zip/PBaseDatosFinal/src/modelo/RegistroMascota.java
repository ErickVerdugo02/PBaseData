/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author Lenovo
 */
public class RegistroMascota 
{
    private Mascota mascota;
    private Persona persona;
    private MascotaTipo mascotaTipo;

    public RegistroMascota(Mascota mascota, Persona persona, MascotaTipo mascotaTipo) {
        this.mascota = mascota;
        this.persona = persona;
        this.mascotaTipo = mascotaTipo;
    }

    public Mascota getMascota() {
        return mascota;
    }

    public void setMascota(Mascota mascota) {
        this.mascota = mascota;
    }

    public Persona getPersona() {
        return persona;
    }

    public void setPersona(Persona persona) {
        this.persona = persona;
    }

    public MascotaTipo getMascotaTipo() {
        return mascotaTipo;
    }

    public void setMascotaTipo(MascotaTipo mascotaTipo) {
        this.mascotaTipo = mascotaTipo;
    }

    @Override
    public String toString() {
        return "RegistroMascota{" + "mascota=" + mascota + ", persona=" + persona + ", mascotaTipo=" + mascotaTipo + '}';
    }
    
}
