/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author Usuario
 */
public class Servicio 
{
    //Atributos del servicio
    private int codigo;
    private String nombre;
    private double precio;
    private char iva;
    private char estado;
    //Constructor del servicio
    public Servicio(int codigo, String nombre, double precio, char iva, char estado) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.precio = precio;
        this.iva = iva;
        this.estado = estado;
    }
    //Getters y Setters del servicio
    public int getCodigo() {
        return codigo;
    }
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public double getPrecio() {
        return precio;
    }
    public void setPrecio(double precio) {
        this.precio = precio;
    }
    public char getIva() {
        return iva;
    }
    public void setIva(char iva) {
        this.iva = iva;
    }
    public char getEstado() {
        return estado;
    }
    public void setEstado(char estado) {
        this.estado = estado;
    }
    //toString del servicio
    @Override
    public String toString() {
        return "Servicio{" + "codigo=" + codigo + ", nombre=" + nombre +
                ", precio=" + precio + ", iva=" + iva + ", estado=" + estado 
                + '}';
    }
}
