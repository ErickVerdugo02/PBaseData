/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.sql.Timestamp;
import java.util.Calendar;

/**
 *
 * @author Usuario
 */
public class Cita 
{
    //Atributos de la cita
    private int codigo;
    private int codigo_mas;
    private int codigo_per;
    private Timestamp fecha;
    private String estado;
    //Constructor de la cita
    public Cita(int codigo_mas, int codigo_per, Timestamp fecha, String estado) {
        this.codigo_mas = codigo_mas;
        this.codigo_per = codigo_per;
        this.fecha = fecha;
        this.estado = estado;
    }

    public Cita(int codigo, int codigo_mas, int codigo_per, Timestamp fecha, String estado) {
        this.codigo = codigo;
        this.codigo_mas = codigo_mas;
        this.codigo_per = codigo_per;
        this.fecha = fecha;
        this.estado = estado;
    }
    
    //Getters y Setters de la cita
    public int getCodigo() {
        return codigo;
    }
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }
    
    public int getCodigo_mas() {
        return codigo_mas;
    }
    public void setCodigo_mas(int codigo_mas) {
        this.codigo_mas = codigo_mas;
    }
    
    public int getCodigo_per() {
        return codigo_per;
    }
    public void setCodigo_per(int codigo_per) {
        this.codigo_per = codigo_per;
    }
    
    public Timestamp getFecha() {
        return fecha;
    }
    public void setFecha(Timestamp fecha) {
        this.fecha = fecha;
    }
    
    public String getEstado() {
        return estado;
    }
    public void setEstado(String estado) {
        this.estado = estado;
    }
    //toString de la cita
    @Override
    public String toString() {
        return "Cita{" + "codigo=" + codigo + ", codigo_mas=" + codigo_mas +
                ", codigo_per=" + codigo_per + ", fecha=" + fecha +
                ", estado=" + estado + '}';
    }
    
}
