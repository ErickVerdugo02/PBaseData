package modelo;

import java.sql.Timestamp;


public class CabeceraFactura 
{
    //Atributos de la cabecera de la factura
    private int codigo;
    private Timestamp fecha;
    private double subtotal;
    private double total_iva;
    private double total;
    private int codigo_per;
    private int codigo_usuario;
    private String estado;
    
    //Constructor de la cabecera de la factura
    public CabeceraFactura(){
        
    }
    public CabeceraFactura(Timestamp fecha, double subtotal, double total_iva, double total, int codigo_per, int codigo_usuario, String estado) {
        this.fecha = fecha;
        this.subtotal = subtotal;
        this.total_iva = total_iva;
        this.total = total;
        this.codigo_per = codigo_per;
        this.codigo_usuario = codigo_usuario;
        this.estado = estado;
    }

    //Getters y Setters
    public void setCodigo(int codigo){
        this.codigo=codigo;
    }
    public int getCodigo(){
        return codigo;
    }
    public Timestamp getFecha() {
        return fecha;
    }

    public void setFecha(Timestamp fecha) {
        this.fecha = fecha;
    }

    public double getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(double subtotal) {
        this.subtotal = subtotal;
    }

    public double getTotal_iva() {
        return total_iva;
    }

    public void setTotal_iva(double total_iva) {
        this.total_iva = total_iva;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public int getCodigo_per() {
        return codigo_per;
    }

    public void setCodigo_per(int codigo_per) {
        this.codigo_per = codigo_per;
    }

    public int getCodigo_usuario() {
        return codigo_usuario;
    }

    public void setCodigo_usuario(int codigo_usuario) {
        this.codigo_usuario = codigo_usuario;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
    
    //Metodos toString
    @Override
    public String toString() {
        return "CabeceraFactura{" + "fecha=" + fecha + ", subtotal=" + subtotal + ", total_iva=" + total_iva + ", total=" + total + ", codigo_per=" + codigo_per + ", codigo_usuario=" + codigo_usuario + ", estado=" + estado + '}';
    }
    
}
