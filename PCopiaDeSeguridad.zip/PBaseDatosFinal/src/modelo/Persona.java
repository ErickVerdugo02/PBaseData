/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author Usuario
 */
public class Persona {
    //Atributos de la persona
    private int codigo;
    private String cedula;
    private String nombres;
    private String apellidos;
    private String direccion;
    private String telefono;
    private String correo;
    private char tipo;
    private char estado;
    //Contstructor de la persona
    public Persona(){
        
    }
    //Crear una persona sin codigo
    public Persona(String cedula, String nombres, String apellidos, String direccion, 
            String correo, String telefono, char tipo, char estado) {
        this.cedula = cedula;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.direccion = direccion;
        this.telefono = telefono;
        this.correo = correo;
        this.tipo = tipo;
        this.estado = estado;
    }
    
    public Persona(int codigo, String cedula, String nombres, String apellidos,
            String direccion, String telefono, String correo, char tipo, char estado) {
        this.codigo = codigo;
        this.cedula = cedula;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.direccion = direccion;
        this.telefono = telefono;
        this.correo = correo;
        this.tipo = tipo;
        this.estado = estado;
    }
    //Getters y Setters de la persona

    public int getCodigo() {
        return codigo;
    }
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }
    public String getCedula() {
        return cedula;
    }
    public void setCedula(String cedula) {
        this.cedula = cedula;
    }
    public String getNombres() {
        return nombres;
    }
    public void setNombres(String nombres) {
        this.nombres = nombres;
    }
    public String getApellidos() {
        return apellidos;
    }
    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }
    public String getDireccion() {
        return direccion;
    }
    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
    public String getTelefono() {
        return telefono;
    }
    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }
    public String getCorreo() {
        return correo;
    }
    public void setCorreo(String correo) {
        this.correo = correo;
    }
    public char getTipo() {
        return tipo;
    }
    public void setTipo(char tipo) {
        this.tipo = tipo;
    }
    public char getEstado() {
        return estado;
    }
    public void setEstado(char estado) {
        this.estado = estado;
    }
    //toString de la persona
    @Override
    public String toString() {
        return "Persona{" + "codigo=" + codigo + ", cedula=" + cedula +
                ", nombres=" + nombres + ", apellidos=" + apellidos +
                ", direccion=" + direccion + ", telefono=" + telefono +
                ", correo=" + correo + ", tipo=" + tipo + ", estado=" +
                estado + '}';
    }
    
    
    
    
}
