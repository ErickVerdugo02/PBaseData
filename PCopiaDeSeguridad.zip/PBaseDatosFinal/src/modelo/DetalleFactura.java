package modelo;


public class DetalleFactura {
    int codigoFacura; 
    int cantidad;
    int servicioCodigo;
    double precio;
    double subtotalDetalle;
    double ivaDetalle;
    double totalDetalle;
    
    //Constructor
    public DetalleFactura(int codigoFacura, int cantidad, int servicioCodigo, double precio, double subtotalDetalle, double ivaDetalle, double totalDetalle) {
        this.codigoFacura = codigoFacura;
        this.cantidad = cantidad;
        this.servicioCodigo = servicioCodigo;
        this.precio = precio;
        this.subtotalDetalle = subtotalDetalle;
        this.ivaDetalle = ivaDetalle;
        this.totalDetalle = totalDetalle;
    }
    
    //Getters y Setters
    public int getCodigoFacura() {
        return codigoFacura;
    }

    public void setCodigoFacura(int codigoFacura) {
        this.codigoFacura = codigoFacura;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public int getServicioCodigo() {
        return servicioCodigo;
    }

    public void setServicioCodigo(int servicioCodigo) {
        this.servicioCodigo = servicioCodigo;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public double getSubtotalDetalle() {
        return subtotalDetalle;
    }

    public void setSubtotalDetalle(double subtotalDetalle) {
        this.subtotalDetalle = subtotalDetalle;
    }

    public double getIvaDetalle() {
        return ivaDetalle;
    }

    public void setIvaDetalle(double ivaDetalle) {
        this.ivaDetalle = ivaDetalle;
    }

    public double getTotalDetalle() {
        return totalDetalle;
    }

    public void setTotalDetalle(double totalDetalle) {
        this.totalDetalle = totalDetalle;
    }
    
    //Metodos toString
    @Override
    public String toString() {
        return "DetalleFactura{" + "codigoFacura=" + codigoFacura + ", cantidad=" + cantidad + ", servicioCodigo=" + servicioCodigo + ", precio=" + precio + ", subtotalDetalle=" + subtotalDetalle + ", ivaDetalle=" + ivaDetalle + ", totalDetalle=" + totalDetalle + '}';
    }
    
}
