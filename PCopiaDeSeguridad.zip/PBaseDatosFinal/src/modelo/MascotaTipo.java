/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author Usuario
 */
public class MascotaTipo 
{
    //Atributos del tipo de mascota
    private int codigo;
    private String nombre;
    
    public MascotaTipo(String nombre){
        this.nombre=nombre;
    }
    //Constructor del tipo de mascota
    public MascotaTipo(int codigo, String nombre) {
        this.codigo = codigo;
        this.nombre = nombre;
    }
    //Getters y Setters del tipo de mascota
    public int getCodigo() {
        return codigo;
    }
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    //toString del tipo de mascota
    @Override
    public String toString() {
        return "MascotaTipo{" + "codigo=" + codigo + ", nombre=" + nombre + '}';
    }
    
    
    
}
