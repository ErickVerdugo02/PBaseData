/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author Usuario
 */
public class Mascota
{
    //Atributos de la mascota
    private int codigo;
    private int codigo_per;
    private int codigo_tipo;
    private String nombre;
    //Construcctor de la persona
    public Mascota(){
        
    }
    public Mascota(int codigo, int codigo_per, int codigo_tipo, String nombre) {
        this.codigo = codigo;
        this.codigo_per = codigo_per;
        this.codigo_tipo = codigo_tipo;
        this.nombre = nombre;
    }
    //Getters y Setters de la mascota
    public int getCodigo() {
        return codigo;
    }
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }
    public int getCodigo_per() {
        return codigo_per;
    }
    public void setCodigo_per(int codigo_per) {
        this.codigo_per = codigo_per;
    }
    public int getCodigo_tipo() {
        return codigo_tipo;
    }
    public void setCodigo_tipo(int codigo_tipo) {
        this.codigo_tipo = codigo_tipo;
    }
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    //toString de la mascota

    @Override
    public String toString() {
        return "Mascota{" + "codigo=" + codigo + ", codigo_per=" + codigo_per +
                ", codigo_tipo=" + codigo_tipo + ", nombre=" + nombre + '}';
    }
    
    
}
